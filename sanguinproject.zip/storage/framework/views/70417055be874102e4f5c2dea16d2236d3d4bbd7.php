<?php $__env->startSection('content'); ?>

            <!--Title Section-->
            <section class="title-section">
                <div class="auto-container">
                    <div class="text">AidNov™, <span class="theme_color">la 1ère plateforme digitale de collecte de
                            fonds</span> aux profits d'êtres et de causes qui vous sont chers.</div>
                </div>
            </section>
            <!--End Title Section-->

            <!--Default Section-->
            <section class="default-section style-two">
                <div class="auto-container">
                    <div class="row clearfix">
                        <div class="video-column col-md-6 col-sm-12 col-xs-12">
                            
                         <video width="569" height="409" controls>
                              <source src="Video/joel%20aidnov.mp4" type="video/mp4">
                              <source src="Video/joel%20aidnov.mpg" type="video/mpg">
                              <source src="Video/joel%20aidnov.m4v" type="video/m4v">
                              <source src="Video/joel%20aidnov.wmv" type="video/wmv">
                              <source src="Video/joel aidnov.mov" type="video/mov">
                              <source src="Video/joel aidnov.mpeg" type="video/mpeg">
                              <source src="Video/joel aidnov.ogv" type="video/ogv">
                              <source src="Video/joel aidnov.webm" type="video/webm">
                         </video>
                        </div>

                        <!--About Column Two-->
                        <div class="about-column-two col-md-6 col-sm-12 col-xs-12">
                            <div class="inner-box">
                                <h2>À propos </h2>
                                <div class="text">AidNov™ est une plateforme digitale qui exploite la puissance des
                                    réseaux sociaux et Internet pour donner aux gens les moyens de récolter des fonds,
                                    s’entraider en cas de difficultés et atteindre des objectifs ambitieux. <br>
                                    Sur la plateforme AidNov™, vous pouvez aider un(e) ami(e) ou toute une communauté.
                                    Vous pouvez tout faire : financer votre intervention chirurgicale, réaliser le rêve
                                    d’un étudiant en l’envoyant à l’université et bien plus encore... </div>
                                <ul class="list-style-two">
                                    <li>Possibilité de créer des campagnes de collecte de fonds.</li>
                                    <li>Possibilité de faire des dons à des cas sensibles.</li>
                                    <li>Possibilité de devenir Ambassadeur et aider des personnes.</li>
                                </ul>
                                <div class="clearfix">
                                    <!--Author Info-->
                                    <div class="author-info pull-left">
                                        <div class="img-thumb">
                                            <img src="/assets/images/resource/Joel 75x76.jpg" alt="" />
                                        </div>
                                        <h4>Joel S. P. Gnakale</h4>
                                        <div class="designation">CEO & Founder LoHiDi<span id="®">®</span> Group</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
    </div>
    </section>
    <!--End Default Section-->

    <!--Who We Are-->
    <section class="who-we-are-section">
        <div class="auto-container">
            <!--Services Title-->

            <div class="clearfix">

                <!--Services Style One-->
                <div class="services-style-one col-md-4 col-sm-6 col-xs-12">
                    <div class="inner-box">
                        <div class="icon-box">
                            <span class="icon flaticon-donation"></span>
                        </div>
                        <h3><a href="inscription.html">Démarrer <br>une campagne</a></h3>
                        <div class="text">Il est maintenant facile de démarrer une cagnotte

                            solidaire pour collecter rapidement des fonds.</div>
                    </div>
                </div>

                <!--Services Style One-->
                <div class="services-style-one col-md-4 col-sm-6 col-xs-12">
                    <div class="inner-box">
                        <div class="icon-box">
                            <span class="icon flaticon-piggy-bank"></span>
                        </div>
                        <h3><a href="cat%C3%A9gories_de_causes.html">Faire <br>un don</a></h3>
                        <div class="text">Il est maintenant facile de faire un don à un être

                            ou à des causes qui vous passionnent le plus.</div>
                    </div>
                </div>

                <!--Services Style One-->
                <div class="services-style-one col-md-4 col-sm-6 col-xs-12">
                    <div class="inner-box">
                        <div class="icon-box">
                            <span class="icon flaticon-donation-1"></span>
                        </div>
                        <h3><a href="ambassadeur.html">Devenir <br> un Ambassadeur</a></h3>
                        <div class="text">Il est maintenant facile d’acquérir une perspective
                                        unique en participant à nos différentes activités.</div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End Services Section-->

    <!--Counter Section-->
    <section class="counter-section" style="background-image:url(/assets/images/background/1.jpg);">
        <div class="auto-container">
            <div class="row clearfix">

                <div class="fact-counter">
                    <div class="row clearfix">

                        <!--Column-->
                        <!--Column-->
                        <div class="column counter-column wow fadeIn col-md-3 col-sm-6 col-xs-12" data-wow-delay="0ms"
                            data-wow-duration="0ms">
                            <div class="inner">

                                <div class="count-outer count-box">
                                    <span class="count-text" data-speed="2500" data-stop="1479">0</span>
                                </div>
                                <h4 class="counter-title">Campagnes Completées</h4>
                            </div>
                        </div>

                        <div class="column counter-column wow fadeIn col-md-3 col-sm-6 col-xs-12" data-wow-delay="0ms"
                            data-wow-duration="0ms">
                            <div class="inner">

                                <div class="count-outer count-box">
                                    <span class="dollor-sign"></span>
                                    <span class="count-text" data-speed="6000" data-stop="388.631">0</span>FCFA
                                </div>
                                <h4 class="counter-title">Dons collectés</h4>
                            </div>
                        </div>

                        <div class="column counter-column wow fadeIn col-md-3 col-sm-6 col-xs-12" data-wow-delay="0ms"
                            data-wow-duration="0ms">
                            <div class="inner">

                                <div class="count-outer count-box">
                                    <span class="dollor-sign"></span>
                                    <span class="count-text" data-speed="6000" data-stop="388.631">0</span>FCFA
                                </div>
                                <h4 class="counter-title">Fonds attribués</h4>
                            </div>
                        </div>

                        <!--Column-->
                        <div class="column counter-column wow fadeIn col-md-3 col-sm-6 col-xs-12" data-wow-delay="0ms"
                            data-wow-duration="0ms">
                            <div class="inner">

                                <div class="count-outer count-box">
                                    <span class="count-text" data-speed="3000" data-stop="2560">0</span>
                                    <span class="plus-tag">+</span>
                                </div>
                                <h4 class="counter-title">Ambassadeurs</h4>
                            </div>
                        </div>

                        <!--Column-->

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End Counter Section-->

    <!--Team Section-->
    <section class="team-section">
        <div class="auto-container">
            <!--Sec Title-->
            <div class="sec-title centered">
                <h2>Notre équipe</h2>
                <h3 style="color: black;">Une entreprise à grande vision</h3>
                <div class="text">LoHiDi<span class="custom-trademark"><span id="®">®</span></span> Group a pour
                    objectif d'élaborer et d’apporter des solutions numériques afin de simplifier la vie de tous.</div>
            </div>
            <div class="row clearfix">

                <!--Team Member-->
                <div class="team-member col-md-3 col-sm-6 col-xs-12">
                    <div class="inner-box">
                        <div class="image">
                            <img src="/assets/images/resource/team-1.jpg" alt="" />
                            <div class="overlay-box">
                                <ul class="social-icon-four">
                                    <li><a href="https://www.linkedin.com/in/joel-s-p-gnakale-b48169194/"
                                            target="_blank"><span class="fa fa-linkedin"></span></a></li>
                                </ul>
                            </div>

                        </div>
                        <div class="lower-box">
                            <h3>Joël S. P. Gnakale</h3>
                            <div class="designation">Chief Executive Officer</div>
                        </div>
                    </div>
                </div>

                <div class="team-member col-md-3 col-sm-6 col-xs-12">
                    <div class="inner-box">
                        <div class="image">
                            <img src="/assets/images/resource/team-7.jpg" alt="" />
                            <div class="overlay-box">
                                <ul class="social-icon-four">
                                    <li><a href="https://www.linkedin.com/in/sahi-ibrahim-soumahoro-4972488a/"
                                            target="_blank"><span class="fa fa-linkedin"></span></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="lower-box">
                            <h3>Ibrahim Soumahoro</h3>
                            <div class="designation">Chief Technology Officer</div>
                        </div>
                    </div>
                </div>

                <div class="team-member col-md-3 col-sm-6 col-xs-12">
                    <div class="inner-box">
                        <div class="image">
                            <img src="/assets/images/resource/Abiba 2.jpg" alt="" />
                            <div class="overlay-box">
                                <ul class="social-icon-four">
                                    <li><a href="https://www.linkedin.com/" target="_blank"><span
                                                class="fa fa-linkedin"></span></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="lower-box">
                            <h3>Habiba D. Ouattara</h3>
                            <div class="designation">Assistant of The CEO & Founder</div>
                        </div>
                    </div>
                </div>

                <div class="team-member col-md-3 col-sm-6 col-xs-12">
                    <div class="inner-box">
                        <div class="image">
                            <img src="/assets/images/resource/team-5.jpg" alt="" />
                            <div class="overlay-box">
                                <ul class="social-icon-four">
                                    <li><a href="https://www.linkedin.com/in/pascal-thibaud-101700149/"
                                            target="_blank"><span class="fa fa-linkedin"></span></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="lower-box">
                            <h3>Pascal O. Thibaud</h3>
                            <div class="designation">Manager, Digital Solutions </div>
                        </div>
                    </div>
                </div>

                <div class="team-member col-md-3 col-sm-6 col-xs-12">
                    <div class="inner-box">
                        <div class="image">
                            <img src="/assets/images/resource/team-3.jpg" alt="" />
                            <div class="overlay-box">
                                <ul class="social-icon-four">
                                    <li><a href="https://www.linkedin.com/in/serge-g-oue-08aba8196/"
                                            target="_blank"><span class="fa fa-linkedin"></span></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="lower-box">
                            <h3>Serge G. Oué</h3>
                            <div class="designation">Manager, IT Solutions</div>
                        </div>
                    </div>
                </div>
                <!--Team Member-->
                <div class="team-member col-md-3 col-sm-6 col-xs-12">
                    <div class="inner-box">
                        <div class="image">
                            <img src="/assets/images/resource/team-2.jpg" alt="" />
                            <div class="overlay-box">
                                <ul class="social-icon-four">
                                    <li><a href="https://www.linkedin.com/in/chris-aka-635234181/" target="_blank"><span
                                                class="fa fa-linkedin"></span></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="lower-box">
                            <h3>Chris H. Aka </h3>
                            <div class="designation">Intern, Web Developer</div>
                        </div>
                    </div>
                </div>

                <!--Team Member-->

                <div class="team-member col-md-3 col-sm-6 col-xs-12">
                    <div class="inner-box">
                        <div class="image">
                            <img src="/assets/images/resource/team-4.jpg" alt="" />
                            <div class="overlay-box">
                                <ul class="social-icon-four">
                                    <li><a href="https://www.linkedin.com/in/herve-wilfried-gnahore-2b1b94177/"
                                            target="_blank"><span class="fa fa-linkedin"></span></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="lower-box">
                            <h3>Wilfried H. Gnahore</h3>
                            <div class="designation">Full Stack Developer </div>
                        </div>
                    </div>
                </div>

                <div class="team-member col-md-3 col-sm-6 col-xs-12">
                    <div class="inner-box">
                        <div class="image">
                            <img src="/assets/images/resource/team-6.jpg" alt="" />
                            <div class="overlay-box">
                                <ul class="social-icon-four">
                                    <li><a href="https://www.linkedin.com/in/liliane-guede-909a381ab/"
                                            target="_blank"><span class="fa fa-linkedin"></span></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="lower-box">
                            <h3>Liliane A. Guede</h3>
                            <div class="designation">Visual Designer</div>
                        </div>
                    </div>
                </div>

                <!--Team Member-->

            </div>
        </div>
    </section>
    <!--End Team Section-->

    <!--Testimonial Section Two-->
    <section class="testimonial-section-two">
        <div class="auto-container">
            <h2>Témoignages!!</h2>
            <div class="three-item-carousel owl-carousel owl-theme">

                <!--Testimonial Block Two-->
                <div class="testimonial-block-two">
                    <div class="inner-box">
                        <div class="content">
                            <div class="author">
                                <div class="image">
                                    <img src="/assets/images/resource/author-5.jpg" alt="" />
                                </div>
                                <h3>Bénédicte Tra lou</h3>
                                <div class="designation">De la Côte d'ivoire</div>
                            </div>
                            <div class="text">J'aime cette plateforme, elle me permet de faire des dons sans me
                                déplacer.</div>
                            <div class="clearfix">
                                <div class="pull-left">
                                    <div class="date">01 juin 2020</div>
                                </div>
                                <div class="pull-right">
                                    <div class="quote-icon"><span class="flaticon-left-quote-1"></span></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!--Testimonial Block Two-->
                <div class="testimonial-block-two">
                    <div class="inner-box">
                        <div class="content">
                            <div class="author">
                                <div class="image">
                                    <img src="/assets/images/resource/author-6.jpg" alt="" />
                                </div>
                                <h3>Rashed Kabir</h3>
                                <div class="designation">Du Maroc</div>
                            </div>
                            <div class="text">AidNov est géniale, redonnez du sourire aux gens depuis l'autre coté du
                                monde.</div>
                            <div class="clearfix">
                                <div class="pull-left">
                                    <div class="date">28 jan 2020</div>
                                </div>
                                <div class="pull-right">
                                    <div class="quote-icon"><span class="flaticon-left-quote-1"></span></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!--Testimonial Block Two-->
                <div class="testimonial-block-two">
                    <div class="inner-box">
                        <div class="content">
                            <div class="author">
                                <div class="image">
                                    <img src="/assets/images/resource/author-7.jpg" alt="" />
                                </div>
                                <h3>Muhibbur Rashid</h3>
                                <div class="designation">From Accra</div>
                            </div>
                            <div class="text">Super, c'est sécurisé et rapide. Très belle initiative, chapeau à l'équipe
                                LoHiDi Group.</div>
                            <div class="clearfix">
                                <div class="pull-left">
                                    <div class="date">14 Avril 2020</div>
                                </div>
                                <div class="pull-right">
                                    <div class="quote-icon"><span class="flaticon-left-quote-1"></span></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End Testimonial Section Two-->
    <!--Call To Action Section-->
    <section class="call-to-action-section" style="background-image:url(/assets/images/background/2.jpg);">
        <div class="auto-container">
            <h2>Devenir un Ambassadeur</h2>
            <div class="text">Rejoignez-nous et devenez un véritable héro et faites sourire le monde !!</div>
            <a href="ambassadeur.html" class="theme-btn btn-style-three">Devenir un Ambassadeur</a>
        </div>
    </section>
    <!--End Call To Action Section-->

    <!--Sponsors Section-->
    <section class="sponsors-section">
        <div class="auto-container">
            <div class="carousel-outer">
                <!--Sponsors Slider-->
                <ul class="sponsors-carousel owl-carousel owl-theme">
                    <li><div class="image-box"><a><img src="/assets/images/clients/1.png"></a></div></li>
                    <li><div class="image-box"><a><img src="/assets/images/clients/2.png"></a></div></li>
                    <li><div class="image-box"><a><img src="/assets/images/clients/3.png"></a></div></li>
                    <li><div class="image-box"><a><img src="/assets/images/clients/4.png"></a></div></li>
                    <li><div class="image-box"><a><img src="/assets/images/clients/1.png"></a></div></li>
                    <li><div class="image-box"><a><img src="/assets/images/clients/2.png"></a></div></li>
                    <li><div class="image-box"><a><img src="/assets/images/clients/3.png"></a></div></li>
                    <li><div class="image-box"><a><img src="/assets/images/clients/4.png"></a></div></li>
                </ul>
            </div>
        </div>
    </section>
    <!--End Sponsors Section-->

    <!--Subscribe Style One-->
    <section class="subscribe-style-one">
        <div class="auto-container">
            <div class="row clearfix">
                <div class="col-md-8 col-sm-12 col-xs-12">
                    <h2>Souscrire aux Newsletters</h2>
                    <div class="text">Entrer votre e-mail pour en savoir plus et rester en contact avec l'équipe AidNov™</div></div>
                <div class="col-md-4 col-sm-12 col-xs-12">
                    <form method="post" action="contact.html">
                        <div class="form-group">
                            <input type="email" name="email" value="" placeholder="Entrer votre e-mail" required>
                            <button type="submit" class="theme-btn"><span
                                    class="icon flaticon-send-message-button"></span></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <!--End Subscribe Style One-->

<?php $__env->stopSection(); ?>


<?php $__env->startSection('extra-js'); ?>
    <script>
        
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/frontendother', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ProjectF\resources\views/frontend/a_propos.blade.php ENDPATH**/ ?>