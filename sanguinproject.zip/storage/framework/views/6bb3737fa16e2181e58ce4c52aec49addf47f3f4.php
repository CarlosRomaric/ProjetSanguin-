<?php $__env->startSection('content'); ?>
 <!--Page Title-->
        <section class="page-title" style="background-color: #376E50;">
            <div class="auto-container">
                <div class="inner-box">
                    <h3>Liste des Departements</h3>
                </div>
            </div>
        </section>
<!--End Page Title-->
     <!--Causes Section-->
        <section class="causes-section causes-grid-page">
            <div class="auto-container">
                <div class="row clearfix">
                     <?php if(Auth::user()->role==0): ?>
                        <?php echo $__env->make('inc/info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?>
                    <!--Causes Block-->
                    <form action="<?php echo e(route('departement.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                        <div class="form-group row">
                            <label for="libelle" class="col-md-3">Departement</label>
                            <div class="col-md-6">
                                <input type="text"  name="libelle" class="form-control" id="libelle" placeholder="Enter le departement">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="libelle" class="col-md-3">pays</label>
                            <div class="col-md-6">
                              
                                <select name="pays_id" id="" class="form-control">
                                 <?php $__currentLoopData = $pays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($p->id); ?>"><?php echo e($p->libelle); ?></option>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>   
                            </div>
                        </div>
                        <button type="submit" class="btn btn-success">Enregistrer</button>
                   </form>
                    <!--Causes Block-->
                    <!--<a href="<?php echo e(route('causeBack.create')); ?>" class="btn btn-primary">Enregistrer une cause</a>-->
                   
                    <br>
                    <div class="table-responsive my-4">
                        <table class="table table-bordered text-center" id="example2">
                            <thead>
                            <tr>
                                    <th>Libellé</th> 
                                    <th>Pays</th> 
                                    <th>Action</tr>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $departements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($departement->libelle); ?></td>                                   
                                    <td><?php echo e($departement->pays->libelle); ?></td>                                   
                                    <td>
                                        <a href="#" class="btn btn-primary">Modifier</a>
                                        <button type="button" class="btn btn-danger">Supprimer </button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                   
                    
                    
                    
                    <!--Causes Block-->
                
                </div>
        </section>
        <!--End Causes Section-->

      

       
       
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-js'); ?>
    <script>
            $(document).ready(function() {
              
                $("#example1").DataTable();
                $('#example2').DataTable({
                "paging": true,
                "lengthChange": true,
                "searching": true,
                "ordering": true,
                "info": true,
                "autoWidth": false,
                "language": {
                        processing:     "Traitement en cours...",
                        search:         "Rechercher&nbsp;:",
                        lengthMenu:     "Afficher _MENU_ &eacute;l&eacute;ments",
                        info:           "Affichage de l'&eacute;lement _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
                        infoEmpty:      "Affichage de l'&eacute;lement 0 &agrave; 0 sur 0 &eacute;l&eacute;ments",
                        infoFiltered:   "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
                        infoPostFix:    "",
                        loadingRecords: "Chargement en cours...",
                        zeroRecords:    "Aucun &eacute;l&eacute;ment &agrave; afficher",
                        emptyTable:     "Aucune donnée disponible dans le tableau",
                        paginate: {
                            first:      "Premier",
                            previous:   "Pr&eacute;c&eacute;dent",
                            next:       "Suivant",
                            last:       "Dernier"
                        },
                        aria: {
                            sortAscending:  ": activer pour trier la colonne par ordre croissant",
                            sortDescending: ": activer pour trier la colonne par ordre décroissant"
                        }
                    }
                });
            });

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ProjectF\resources\views/departement/index.blade.php ENDPATH**/ ?>