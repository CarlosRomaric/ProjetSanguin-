<?php $__env->startSection('content'); ?>
     <!--Page Title-->
        <section class="page-title" style="background-color: #376E50;">
            <div class="auto-container">
                <div class="inner-box">
                    <h3>Tableau de bord</h3>
                </div>
            </div>
        </section>
        <!--End Page Title-->

        <!--Causes Section-->
          <section class="causes-section causes-grid-page">
            <div class="auto-container">
                <div class="row clearfix">

                    <?php if( (Auth::user()->role==0) ): ?>
                      <?php if( ($cause==0) || ($ville ==0 ) || ($departement == 0) || ( $pays==0 ) ): ?>
                        <?php echo $__env->make('inc/info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                      <?php endif; ?>
                    <?php endif; ?>

                    <!--Causes Block-->
                    <div class="causes-block col-md-4 col-sm-6 col-xs-12">
                        <div class="inner-box">
                            <div class="image">
                                <a href="causes-single.html"><img src="/assets/images/resource/causes-2.jpg" alt="" /></a>
                            </div>
                            <div class="lower-box">
                                <div class="content">
                                    <h3>
                                    <a href="<?php echo e(route('campagne.index')); ?>"><?php if(Auth::user()->role==1): ?> Mes campagnes <?php else: ?> Les campagnes <?php endif; ?></a>
                                    </h3>
                                    <div class="text">ACTIVE</div>
                                    <!--<div class="donate-bar wow fadeIn" data-wow-delay="0ms" data-wow-duration="0ms">
                                        <div class="bar-inner">
                                            <div class="bar" style="width:82%;">
                                                <div class="count-box"><span class="count-text" data-speed="2000"
                                                        data-stop="82">0</span>%</div>
                                            </div>
                                        </div>
                                    </div>-->
                                    <div class="causes-info"><strong>Récoltés</strong> 56,000 FCFA / <span
                                            class="theme_color">75,000 FCFA</span></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <?php if(Auth::user()->role == 1): ?>
                    <div class="causes-block col-md-4 col-sm-6 col-xs-12">
                        <div class="inner-box">
                            <div class="image">
                                <a href="causes-single.html"><img src="/assets/images/resource/causes-13.jpg" alt="" /></a>
                            </div>
                            <div class="lower-box">
                                <div class="content">
                                    <h3><a href="<?php echo e(route('campagne.create')); ?>">Démarrer <br>une campagne</a></h3>
                                    <div class="text">Lancer une nouvelle collecte de fonds.</div>
                                    <!--<div class="donate-bar wow fadeIn" data-wow-delay="0ms" data-wow-duration="0ms">
                                        <div class="bar-inner">
                                            <div class="bar" style="width:12%;">
                                                <div class="count-box"><span class="count-text" data-speed=""
                                                        data-stop="00">0</span>%</div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="causes-info"><strong></strong> <br> <span
                                            class="theme_color"></span></div>-->
                                </div>
                            </div>
                        </div>
                    </div> 
                   
                <!--Causes Block-->
                    <div class="causes-block col-md-4 col-sm-6 col-xs-12">
                        <div class="inner-box">
                            <div class="image">
                                <a href="#"><img src="/assets/images/resource/causes-14.jpg" alt="" /></a>
                            </div>
                            <div class="lower-box">
                                <div class="content">
                                    <h3><a href="">Mes collects</a></h3>
                                    <div class="text"> Liste des collects. </div>
                                    <!--<div class="donate-bar wow fadeIn" data-wow-delay="0ms" data-wow-duration="0ms">
                                        <div class="bar-inner">
                                            <div class="bar" style="width:12%;">
                                                <div class="count-box"><span class="count-text" data-speed="2000"
                                                        data-stop="1000">0</span> FCFA</div>
                                            </div>
                                        </div>
                                    </div>!-->
                                    <div class="causes-info"><strong></strong> <span
                                            class="theme_color"><br></span></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!--Causes Block-->
                 <?php endif; ?>
                </div>
             </div>
        </section>
        <!--End Causes Section-->
        <!--End Causes Section-->




        <!--Subscribe Style One-->
        <section class="subscribe-style-one">
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="col-md-8 col-sm-12 col-xs-12">
                        <h2>Souscrire aux Newsletters</h2>
                        <div class="text">Entrer votre e-mail pour en savoir plus et rester en contact avec l'équipe
                            AidNov™</div>
                    </div>
                    <div class="col-md-4 col-sm-12 col-xs-12">
                        <form method="post" action="contact.html">
                            <div class="form-group">
                                <input type="email" name="email" value="" placeholder="Entrer votre e-mail" required>
                                <button type="submit" class="theme-btn"><span
                                        class="icon flaticon-send-message-button"></span></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
        <!--End Subscribe Style One-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ProjectF\resources\views/home.blade.php ENDPATH**/ ?>