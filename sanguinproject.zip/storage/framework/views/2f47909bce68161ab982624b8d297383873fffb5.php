<?php $__env->startSection('content'); ?>
 <!--Page Title-->
        <section class="page-title" style="background-color: #376E50;">
            <div class="auto-container">
                <div class="inner-box">
                    <h3>Liste des Campagnes</h3>
                </div>
            </div>
        </section>
<!--End Page Title-->
     <!--Causes Section-->
        <section class="causes-section causes-grid-page">
            <div class="auto-container">
                <div class="row clearfix">
                     <?php if(Auth::user()->role==0): ?>
                        <?php echo $__env->make('inc/info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?>
                    <!--Causes Block-->
                    <?php if(($campagnes)->count()!=0): ?>
                        <!--<div class="text-center" style="margin-bottom:20px;">   
                                <h2>Liste des campagnes</h2>
                        </div>-->
                        <div class="table-responsive">
                            <table class="table table-bordered text-center" id="example2">
                                <thead>
                                    <tr class="text-center">
                                        <th>Image</th>
                                        <th>Titre</th>
                                        <th>Montant Objectif</th>
                                        <th>Montant collectés</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    
                                   <?php $__currentLoopData = $campagnes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campagne): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   
                                    <tr>
                                       <td><img src="/reduct/<?php echo e($campagne->photo); ?>" alt="<?php echo e($campagne->photo); ?>" alt="" width="50px" class="image-rounded image-responsive"></td>
                                       <td><?php echo e($campagne->titre); ?></td>
                                       <td><?php echo e($campagne->montantObjectif); ?> FCFA</td>
                                       <td>0 FCFA</td>
                                       <td>
                                            <?php 
                                                switch ($campagne->verified) {
                                                case 0:
                                                    echo "Pas encore Validé";
                                                    break;
                                                case 1:
                                                    echo "Validé";
                                                    break;
                                            
                                            }?>
                                            
                                       </td>
                                       <td>
                                       
                                            
                                                <a href="<?php echo e(route('campagne.edit', $campagne->id)); ?>" class="btn btn-primary"> modifier </a>
                                                <button class="btn btn-danger" data-toggle="modal" data-target="#mb-delete_<?php echo e($campagne->id); ?>"> Supprimer </button>
                                                <?php if((Auth::user()->role==0 ) && ($campagne->verified==0)): ?>
                                                <button class="btn btn-info" data-toggle="modal" data-target="#mb-validate_<?php echo e($campagne->id); ?>"> Approuver </button>
                                                <?php endif; ?>
                                                <button class="btn btn-warning"> Details </button> 
                                           
                                            
                                       </td>
                                    </tr>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        

                       
                      
                       
                    <?php else: ?>
                        <h2>Aucune campagne n'a encore été démarée </h2>
                    <?php endif; ?>  
                    <!--Causes Block-->
                
                </div>
        </section>
         <?php $__currentLoopData = $campagnes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campagne): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="modal fade" id="mb-delete_<?php echo e($campagne->id); ?>" tabindex="-1" role="dialog" aria-labelledby="deleteLabel">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h4 class="modal-title login-title" id="myModalLabel">Supprimer <?php echo e($campagne->titre); ?></h4>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                
                            </div>
                            <div class="modal-body">
                                <p>La suppression est irréverssible!!!.
                                    Voulez-vous vraiment Supprimer cetle ligne?</p>
                            </div>
                            <div class="modal-footer">
                                
                                
                                <form action ="<?php echo e(route('campagne.destroy', $campagne->id)); ?>" method="POST">
                                 <?php echo csrf_field(); ?>
                                 <button class="btn btn-default" data-dismiss="modal" type="button">
                                    <i class="fa fa-reply"></i> Annuler
                                </button>
                                <button type="submit" class="btn btn-success">
                                    <i class="fa fa-save"></i> Valider
                                </button> 
                                <input type="hidden" name="_method" value="DELETE">
                                
                                 </form>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php $__currentLoopData = $campagnes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campagne): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="modal fade" id="mb-validate_<?php echo e($campagne->id); ?>" tabindex="-1" role="dialog" aria-labelledby="validateLabel">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h4 class="modal-title login-title" id="myModalLabel">Approuver la campagne <?php echo e($campagne->titre); ?></h4>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                
                            </div>
                             <form action ="<?php echo e(route('validateCampagne', $campagne->id)); ?>" method="POST">
                                 <?php echo csrf_field(); ?>
                                <div class="modal-body">
                                    <p>
                                     valider cette campagne afin quelle apparaisse sur la plateforme
                                    </p>
                                    <textarea name="remarque" class="form-control" id="" cols="30" rows="10" placeholder="indiquer votre remarque" required></textarea>
                                    <input type="hidden" name="_method" value="PUT">
                                    <input type="hidden" value="1" name="verified">
                                </div>
                                <div class="modal-footer">
                                   
                                    <button type="submit" name="valide" value="1" class="btn btn-danger"> <i class="fa fa-save"></i> Rejeter </button> 
                                    <button type="submit" name="valide" value="0" class="btn btn-success pull-right"> <i class="fa fa-save"></i> Valider </button>  
                                </div>
                           </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-js'); ?>
    <script>
            $(document).ready(function() {
              
                $("#example1").DataTable();
                $('#example2').DataTable({
                "paging": true,
                "lengthChange": true,
                "searching": true,
                "ordering": true,
                "info": true,
                "autoWidth": false,
                "language": {
                        processing:     "Traitement en cours...",
                        search:         "Rechercher&nbsp;:",
                        lengthMenu:     "Afficher _MENU_ &eacute;l&eacute;ments",
                        info:           "Affichage de l'&eacute;lement _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
                        infoEmpty:      "Affichage de l'&eacute;lement 0 &agrave; 0 sur 0 &eacute;l&eacute;ments",
                        infoFiltered:   "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
                        infoPostFix:    "",
                        loadingRecords: "Chargement en cours...",
                        zeroRecords:    "Aucun &eacute;l&eacute;ment &agrave; afficher",
                        emptyTable:     "Aucune donnée disponible dans le tableau",
                        paginate: {
                            first:      "Premier",
                            previous:   "Pr&eacute;c&eacute;dent",
                            next:       "Suivant",
                            last:       "Dernier"
                        },
                        aria: {
                            sortAscending:  ": activer pour trier la colonne par ordre croissant",
                            sortDescending: ": activer pour trier la colonne par ordre décroissant"
                        }
                    }
                });
            });

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ProjectF\resources\views/campagnes/index.blade.php ENDPATH**/ ?>