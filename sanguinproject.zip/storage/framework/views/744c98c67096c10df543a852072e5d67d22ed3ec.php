<?php $__env->startSection('content'); ?>
                <!--Sidebar Page Container-->
            <div class="sidebar-page-container blog-page">
                <div class="auto-container">
                    <div class="row clearfix">

                        <!--Content Side-->
                        <div class="content-side col-lg-6 col-md-6 col-sm-6 col-xs-6">

                            <!--News Block-->
                            <div class="news-block">
                                <div class="inner-box">
                                    <div class="image">
                                        <img src="/assets/images/resource/conseil.jpg" alt="" />
                                    </div>

                                </div>
                            </div>

                            <!-- Styled Pagination -->
                            <div class="styled-pagination">
                                <ul class="clearfix">
                                </ul>
                            </div>
                        </div>
                        <!--Content Side-->
                        <div class="content-side col-lg-6 col-md-6 col-sm-6 col-xs-6">

                            <!--News Block-->
                            <div class="news-block">
                                <div class="inner-box">
                                    <div class="lower-box">
                                        <h3>Besoin d’aide Pour Récolter des fonds ? Voici Des Conseils de Pro</h3>
                                        <div class="text"> Vous avez besoin d’argent pour soutenir une cause importante
                                            ? Chez AidNov™, nous voyons des cagnottes atteindre, voire dépasser leur
                                            objectif grâce à nos conseils uniques. Que vous ayez de l’expérience ou pas
                                            en matière de financement participatif, Pour recevoir des conseille de
                                            récole de fonds veuillez nous contacter par formulaire sur la page
                                            <strong>"Contact".</strong></div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>

                    <!-- Popular Tags -->
                </div>
            </div>

            <!--End Causes Section-->

            <!--Subscribe Style One-->
            <section class="subscribe-style-one">
                <div class="auto-container">
                    <div class="row clearfix">
                        <div class="col-md-8 col-sm-12 col-xs-12">
                            <h2>Souscrire aux Newsletters</h2>
                            <div class="text">Entrer votre e-mail pour en savoir plus et rester en contact avec l'équipe
                                AidNov™.</div>
                        </div>
                        <div class="col-md-4 col-sm-12 col-xs-12">
                            <form method="post" action="contact.html">
                                <div class="form-group">
                                    <input type="email" name="email" value="" placeholder="Entrer votre e-mail"
                                        required>
                                    <button type="submit" class="theme-btn"><span
                                            class="icon flaticon-send-message-button"></span></button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </section>
            <!--End Subscribe Style One-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/frontendother', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ProjectF\resources\views/frontend/conseil_pour_collecter.blade.php ENDPATH**/ ?>