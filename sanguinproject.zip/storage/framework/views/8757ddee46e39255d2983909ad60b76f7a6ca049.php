<?php $__env->startSection('content'); ?>
        

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sanguinproject\resources\views/home.blade.php ENDPATH**/ ?>