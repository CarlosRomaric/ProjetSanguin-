<?php $__env->startSection('content'); ?>
    
<?php $__env->startSection; ?>
<?php echo $__env->make('layouts/backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ProjectF\resources\views/causes/index.blade.php ENDPATH**/ ?>