  

  <?php $__env->startSection('content'); ?>
  	<div class="signup-content">
			<form method="POST" id="signup-form" class="signup-form" action="<?php echo e(route('register')); ?>">
				<?php echo csrf_field(); ?>
				<h2 class="form-title">Inscription Sur la plateforme de don de sang Projet Sanguis</h2>
				<div class="form-group">
					<input type="text" class="form-input" name="name" id="name" placeholder="Entrez votre nom et prénoms" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus/>
					 <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
							<span class="invalid-feedback" role="alert">
								<strong><?php echo e($message); ?></strong>
							</span>
                     <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
				</div>
				<div class="form-group">
					<input type="email" class="form-input" name="email" id="email" placeholder="Entrez votre email" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" />
					 <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
						<span class="invalid-feedback" role="alert">
							<strong><?php echo e($message); ?></strong>
						</span>
					 <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
				</div>
				<div class="form-group">
					<input type="phone" class="form-input" onkeypress="chiffres(event)" maxlength="8" name="phone" id="phone" placeholder="Entrez votre téléphone" name="phone" value="<?php echo e(old('phone')); ?>" required autocomplete="phone" />
					 <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?>
						<span class="invalid-feedback" role="alert">
							<strong><?php echo e($message); ?></strong>
						</span>
					 <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
				</div>
				<div class="form-group">
					<input type="text" class="form-input" name="password" id="password" placeholder="Password"/>
					 <?php if ($errors->has('Password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('Password'); ?>
						<span class="invalid-feedback" role="alert">
							<strong><?php echo e($message); ?></strong>
						</span>
                     <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
					<span toggle="#password" class="zmdi zmdi-eye field-icon toggle-password"></span>
				</div>
				
				<div class="form-group">
					<input type="password" class="form-input" name="password_confirmation" id="re_password" placeholder="Repeat your password"/>
				</div>
				<input type="hidden" name="role" value="1">  
				<div class="form-group">
					<input type="submit" name="submit" id="submit" class="form-submit" value="Sign up"/>
				</div>
				
			</form>
			<p class="loginhere">
				Avez vous un compte ? <a href="<?php echo e(route('login')); ?>" class="loginhere-link">Connecter Vous Ici</a>
			</p>
	</div>
  <?php $__env->stopSection(); ?>

  <?php $__env->startSection('extra-js'); ?>
  	 <script>
        //Autoriser que la saisie des chiffres
            function chiffres(event) {
                    // Compatibilité IE / Firefox
                    if(!event&&window.event) {
                    event=window.event;
                    }
                    // IE
                    if(event.keyCode < 48 || event.keyCode > 57 || event.keyCode  == 8 || event.keyCode == 127) {
                    event.returnValue = false;
                    event.cancelBubble = true;
                    }
                    // DOM
                    if(event.which < 48 || event.which > 57 || event.keyCode == 8 || event.keyCode == 127) {
                    event.preventDefault();
                    event.stopPropagation();
                    }
            }
    </script>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sanguinproject\resources\views/auth/register.blade.php ENDPATH**/ ?>