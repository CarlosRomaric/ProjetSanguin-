<!DOCTYPE html>
<!--[if IE 8 ]><html class="ie" xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!-->
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<!--<![endif]-->

<head>

    <!-- Basic Page Needs -->
    <meta charset="utf-8">

    <!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->

    <meta name="LoHiDi® Group" content="lohidi.com">
    <meta name="LoHiDi I IT®" content="it.lohidi.com">
    <meta name="LoHiDi I Creative®" content="creative.lohidi.com">

    <meta property="og:url"           content="http://localhost:8000/" />
    <meta property="og:type"          content="website" />
    <meta property="og:title"         content="Your Website Title" />
    <meta property="og:description"   content="Your description" />
    <meta property="og:image"         content="http://localhost:8000/assets/images/logo.png" />

    <meta name="keywords"
        content="HTML, meta tag, tag reference, aide, donation, abidjan, aidons-nous, aidons, campagne, fonds, collecte de fonds, sante, famille, Commemoration, education, donate, famille, mariage, urgences, causes, crowdfunding, crowd, financement, financement participatif, collection, côte d'ivoire, aidons nous vivants, epidemie, lutter, pauvreté, religion, temoignages, financer, plateforme crowdfunding, project, afrique, africa, make a donation, realiser, entrepreneurs, crowdequity, crowdlending, prêt, investissement, ONG, ambassadeur, benevole, AidNov, LoHiDi® Group, LoHiDi I IT®, LoHiDi, facebook faire un don, aider une personne, #aidonsnousvivant, aidnov, démarrer un campagne, Faire un don, Devenir un Ambassadeur">

    <title>AidNov™ : <?php echo e($title); ?></title>

    <!-- Stylesheets -->
    <link href="/assets/css/bootstrap.css" rel="stylesheet">
    <link href="/assets/css/style.css" rel="stylesheet">
    <link href="/assets/css/responsive.css" rel="stylesheet">

    <!--Color Switcher Mockup-->
    <link href="/assets/css/color-switcher-design.css" rel="stylesheet">

    <!--Color Themes-->
    <link id="theme-color-file" href="/assets/css/color-themes/default-theme.css" rel="stylesheet">

    <!--Color Themes-->
    <link id="theme-color-file" href="/assets/css/color-themes/default-theme.css" rel="stylesheet">

    <!--Favicon-->
    <link rel="shortcut icon" href="/assets/images/favicon.ico" type="image/x-icon">
    <link rel="icon" href="/assets/images/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <!-- Responsive -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">


    <!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
    <!--[if lt IE 9]><script src="/assets/js/respond.js"></script><![endif]-->

</head>

<body>
    <div class="page-wrapper">

        <!-- Preloader -->
        <div class="preloader"></div>

        <!-- Main Header-->
        <header class="main-header header-type-one">

            <!--Header Top-->
            <div class="header-top">
                <div class="auto-container">
                    <div class="clearfix">
                        <div class="top-left">
                            <ul class="clearfix">
                                <li><span class="icon fa fa-clock-o"></span> Lun-Sam: 8:00-17:00</li>
                                <li><span class="icon fa fa-envelope"></span><a href="mailto:aide@aidnov.com"
                                        target="_blank" style="color:#fff">aide@aidnov.com</a></li>
                            </ul>
                        </div>
                        <div class="top-right clearfix">
                            <ul class="social-icon-one">
                                <li><a href="<?php echo e(route('login')); ?> ">Se connecter /</a>
                                    <a href="<?php echo e(route('register')); ?>">S'inscrire</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <!--Header-Upper-->
            <div class="header-upper">
                <div class="auto-container">
                    <div class="clearfix">

                        <div class="pull-left logo-outer">
                            <div class="logo"><a href="/"><img src="/assets/images/logo.png" alt="" title=""></a></div>
                        </div>

                        <div class="nav-outer clearfix">

                            <!-- Main Menu -->
                            <nav class="main-menu">
                                <div class="navbar-header">
                                    <!-- Toggle Button -->
                                    <button type="button" class="navbar-toggle" data-toggle="collapse"
                                        data-target=".navbar-collapse">
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                    </button>
                                </div>
                                <div class="navbar-collapse collapse clearfix">
                                     <?php echo $__env->make('inc/ulnavigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </nav>

                            <!-- Main Menu End-->

                            <!--Donate Btn-->
                            <div class="donate-btn">
                                <a class="donate theme-btn" href="inscription.html" id="demarre">Démarrer une
                                    campagne</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--End Header Upper-->

            <!--Sticky Header-->
            <div class="sticky-header">
                <div class="auto-container clearfix">
                    <!--Logo-->
                    <div class="logo pull-left">
                        <a href="/" class="img-responsive"><img src="/assets/images/logo-small.png" alt=""
                                title=""></a>
                    </div>

                    <!--Right Col-->
                    <div class="right-col pull-right">
                        <!-- Main Menu -->
                        <nav class="main-menu">
                            <div class="navbar-header">
                                <!-- Toggle Button -->
                                <button type="button" class="navbar-toggle" data-toggle="collapse"
                                    data-target=".navbar-collapse">
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                            </div>

                            <div class="navbar-collapse collapse clearfix">
                                <?php echo $__env->make('inc/ulnavigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>

                            <!-- Main Menu End-->
                    </div>
                </div>
            </div>
            <!--End Sticky Header-->

            <!--Page Title-->
            <section class="page-title" style="background-color: #376E50;">
                <div class="auto-container">
                    <div class="inner-box" style="height: 70px;">
                        <h3><?php echo e($title); ?></h3>
                    </div>
                </div>
            </section>
            <!--End Page Title-->
            <?php echo $__env->yieldContent('content'); ?>
    <footer class="main-footer">
        <div class="auto-container">
            <div class="row clearfix">

                <!--big column-->
                <div class="big-column col-md-7 col-sm-12 col-xs-12">
                    <div class="row clearfix">

                        <!--Footer Column-->
                        <div class="footer-column col-md-6 col-sm-6 col-xs-12">
                            <div class="footer-widget logo-widget">
                                <div class="widget-content">
                                    <div class="logo-box">
                                        <a href="/"><img src="/assets/images/footer-logo.png" alt="" /></a>
                                    </div>
                                    <div class="text">La plateforme n°1 de collecte de fonds en ligne pour des
                                        campagnes au profit d'êtres et de causes qui vous sont chers. </div>
                                    <ul class="social-icon-two">
                                        <li><a href="https://www.facebook.com/aidnov" target="_blank"><span class="fa fa-facebook"></span></a></li>
                                        <li><a href="  https://www.instagram.com/aidnov_/" target="_blank"><span class="fa fa-instagram"></span></a></li>
                                        <li><a href="https://www.twitter.com/AidNov" target="_blank"><span class="fa fa-twitter"></span></a></li>
                                        <li><a href="https://www.youtube.com/channel/UCDdh2VwSi7EFndb6dqpuSMA" target="_blank"><span class="fa fa-youtube"></span></a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <!--Footer Column / Links Widget-->
                        <div class="footer-column col-md-6 col-sm-6 col-xs-12">
                            <div class="footer-widget links-widget">
                                <h2>Liens rapides</h2>
                                <div class="widget-content">
                                    <div class="row clearfix">
                                        <ul class="list col-md-7 col-sm-6 col-xs-12">
                                            <li><a href="<?php echo e(route('a_propos')); ?>">À propos </a></li>
                                            <li><a href="<?php echo e(route('mode_emploi')); ?>">Mode d'emploi </a></li>
                                            <li><a href="<?php echo e(route('campagneFront')); ?>">Causes</a></li>
                                            <li><a href="<?php echo e(route('register')); ?>">Démarrer une campagne</a></li>
                                            <li><a href="<?php echo e(route('campagneFront')); ?>">Faire un don</a></li>
                                        </ul>
                                            <ul class="list col-md-5 col-sm-6 col-xs-12">
                                                <li><a href="<?php echo e(route('ambassadeur')); ?>">Devenir un Ambassadeur</a></li>
                                                <li><a href="<?php echo e(route('temoignages')); ?>">Témoignages</a></li>
                                                <li><a href="https://www.apple.com/ios/app-store/">iOS App</a></li>
                                                <li><a href="https://play.google.com/store/apps">Android App</a></li>
                                                <li><a href="<?php echo e(route('contact')); ?>">Contact</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!--big column-->
                    <div class="big-column col-md-5 col-sm-12 col-xs-12">
                        <div class="row clearfix">

                            <!--Footer Column-->
                            <div class="footer-column col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                <div class="footer-widget gallery-widget">
                                    <h2>L'équipe</h2>
                                    <div class="widget-content">
                                        <div class="images-outer clearfix">
                                            <!--Image Box-->
                                            <figure class="image-box"><img src="/assets/images/gallery/footer-gallery-thumb-1.jpg" alt=""></figure>
                                            <figure class="image-box"><img src="/assets/images/gallery/footer-gallery-thumb-2.jpg" alt=""></figure>
                                            <figure class="image-box"><img src="/assets/images/gallery/footer-gallery-thumb-3.jpg" alt=""></figure>
                                            <figure class="image-box"><img src="/assets/images/gallery/footer-gallery-thumb-4.jpg" alt=""></figure>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!--Footer Column-->
                            <div class="footer-column col-md-6 col-sm-6 col-xs-12">
                                <div class="footer-widget address-widget">
                                    <h2>Contact</h2>
                                    <div class="widget-content">
                                        <ul class="list-style-one">
                                            <li><span class="icon flaticon-location-pin"></span>B54, Rue du Lycée Technique Cocody, Abidjan</li>
                                            <li><span class="icon fa fa-clock-o"></span> Lun-Sam: 8:00-17:00</li>
                                            <li><span class="icon flaticon-e-mail-envelope"></span><a href="mailto:aide@aidnov.com" style="color: rgb(160, 170, 179);" target="_blank">aide@aidnov.com</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            <!--Footer Bottom-->
            <div class="footer-bottom">
                <div class="auto-container">
                    <div class="row clearfix">
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="copyright"> © 2020 AidNov™ – A product of LoHiDi<span
                                    class="custom-trademark"><span id="®">®</span></span> Group. Tous droits
                                réservés.<br>Développé avec ❤️ à Abidjan, Côte d’Ivoire 🇨🇮 par <a
                                    href="https://it.lohidi.com" target="_blank" id="lien" style="color: #fff;"> LoHiDi
                                    I IT<span id="®">®</span></a></div></div>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <ul class="footer-nav">
                                <li><a href="https://drive.google.com/file/d/1ear0aODVdu8ew042SOXMM0MQ9ljYDrPn/view?usp=sharing"
                                        target="_blank">Conditions générales d'utilisation</a></li>
                                <li><a href="https://drive.google.com/file/d/1EYm7Hg4i2_qOxnh0_kAnuLUiuA-zU5Kg/view?usp=sharing"
                                        target="_blank">Politique de confidentialité</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
    <!--End pagewrapper-->

	<script src="/assets/js/jquery.js"></script>
	<script src="/assets/js/bootstrap.min.js"></script>
	<script src="/assets/js/revolution.min.js"></script>
	<script src="/assets/js/jquery.fancybox.pack.js"></script>
	<script src="/assets/js/jquery.fancybox-media.js"></script>
	<script src="/assets/js/owl.js"></script>
	<script src="/assets/js/appear.js"></script>
	<script src="/assets/js/wow.js"></script>
	<script src="/assets/js/script.js"></script>
	<!-- <script src="/assets/js/main-2.js"></script> -->
	<script src="/assets/js/color-settings.js"></script>
	
    <?php echo $__env->yieldContent('extra-js'); ?>
</body>

</html><?php /**PATH C:\wamp64\www\ProjectF\resources\views/layouts/frontendother.blade.php ENDPATH**/ ?>