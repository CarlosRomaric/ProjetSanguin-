<?php echo e($slot); ?>

<?php /**PATH C:\wamp64\www\ProjectF\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>