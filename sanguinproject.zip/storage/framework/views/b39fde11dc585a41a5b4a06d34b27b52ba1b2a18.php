<?php $__env->startSection('content'); ?>
	<div class="signup-content">
	<a href="<?php echo e(route('member.create')); ?>" class="a-none my-5 form-submit">Inscription sur la plateforme Projet Sanguis</a>
	<br><br>
			<form method="POST" id="signup-form" class="signup-form" action="<?php echo e(route('login')); ?>">
				<?php echo csrf_field(); ?>
				<h2 class="form-title">Se Connecter la plateforme de don de sang Projet Sanguis</h2>
				
				<div class="form-group">
					<input type="email" class="form-input" name="email" id="email" placeholder="Entrez votre login" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus/>
					 <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
							<span class="invalid-feedback" role="alert">
								<strong><?php echo e($message); ?></strong>
							</span>
                     <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
				</div>
				<div class="form-group">
					<input type="text" class="form-input" name="password" id="password" name="password" required autocomplete="current-password" placeholder="Password"/>

					<span toggle="#password" class="zmdi zmdi-eye field-icon toggle-password"></span>
					 <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
							<span class="invalid-feedback" role="alert">
								<strong><?php echo e($message); ?></strong>
							</span>
                     <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
				</div>
				
				<div class="form-group">
					<input type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>  class="agree-term" />
					<label for="agree-term" class="label-agree-term"><span><span></span></span> <?php echo e(__('Remember Me')); ?>  <a href="#" class="term-service">Terms of service</a></label>
				</div>
				<div class="form-group">
					<input type="submit" name="submit" id="submit" class="form-submit" value="Sign up"/>
				</div>

				 <?php if(Route::has('password.request')): ?>
						<a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
							J'ai oublier mon mot de passe
						</a>
                 <?php endif; ?>
			</form>
			<p class="loginhere">
				ouvrir un compte <a href="<?php echo e(route('register')); ?>" class="loginhere-link">S'inscrire</a>
			</p>
	</div>
<?php $__env->stopSection(); ?>
	
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sanguinproject\resources\views/auth/login.blade.php ENDPATH**/ ?>