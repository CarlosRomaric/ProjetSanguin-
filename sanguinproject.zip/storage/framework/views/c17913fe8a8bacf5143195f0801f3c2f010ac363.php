<?php $__env->startSection('content'); ?>


        <!--Sidebar Page Container-->
        <section class="testimonial-section-two">
            <div class="auto-container">

                <div class="three-item-carousel owl-carousel owl-theme">

                    <!--Testimonial Block Two-->
                    <div class="testimonial-block-two">
                        <div class="inner-box">
                            <div class="content">
                                <div class="author">
                                    <div class="image">
                                        <img src="/assets/images/resource/author-5.jpg" alt="" />
                                    </div>
                                    <h3>Bénédicte Tra lou</h3>
                                    <div class="designation">De la Côte d'ivoire</div>
                                </div>
                                <div class="text">J'aime cette plateforme, elle me permet de faire des dons sans me
                                    déplacer.</div>
                                <div class="clearfix">
                                    <div class="pull-left">
                                        <div class="date">01 juin 2020</div>
                                    </div>
                                    <div class="pull-right">
                                        <div class="quote-icon"><span class="flaticon-left-quote-1"></span></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!--Testimonial Block Two-->
                    <div class="testimonial-block-two">
                        <div class="inner-box">
                            <div class="content">
                                <div class="author">
                                    <div class="image">
                                        <img src="/assets/images/resource/author-6.jpg" alt="" />
                                    </div>
                                    <h3>Rashed Kabir</h3>
                                    <div class="designation">Du Maroc</div>
                                </div>
                                <div class="text">AidNov est géniale, redonnez du sourire au gens en besoin depuis
                                    l'autre coté du monde.</div>
                                <div class="clearfix">
                                    <div class="pull-left">
                                        <div class="date">28 jan 2020</div>
                                    </div>
                                    <div class="pull-right">
                                        <div class="quote-icon"><span class="flaticon-left-quote-1"></span></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!--Testimonial Block Two-->
                    <div class="testimonial-block-two">
                        <div class="inner-box">
                            <div class="content">
                                <div class="author">
                                    <div class="image">
                                        <img src="/assets/images/resource/author-7.jpg" alt="" />
                                    </div>
                                    <h3>Muhibbur Rashid</h3>
                                    <div class="designation">From Accra</div>
                                </div>
                                <div class="text">Super, c'est sécurisé et rapide. Très belle initiative, chapeau a
                                    l'équipe LoHiDi Group..</div>
                                <div class="clearfix">
                                    <div class="pull-left">
                                        <div class="date">14 Avril 2020</div>
                                    </div>
                                    <div class="pull-right">
                                        <div class="quote-icon"><span class="flaticon-left-quote-1"></span></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!--End Causes Section-->

        <!--Call To Action Section-->
        <section class="call-to-action-section" style="background-image:url(/assets/images/background/2.jpg);">
            <div class="auto-container">
                <h2>Devenir un Ambassadeur</h2>
                <div class="text">Rejoignez-nous, devenez un héros et faites sourire le monde !!</div>
                <a href="ambassadeur.html" class="theme-btn btn-style-three">Devenir un Ambassadeur</a>
            </div>
        </section>
        <!--End Call To Action Section-->


        <!--Sponsors Section-->
        <section class="sponsors-section">
            <div class="auto-container">
                <div class="carousel-outer">
                    <!--Sponsors Slider-->
                    <ul class="sponsors-carousel owl-carousel owl-theme">
                        <li>
                            <div class="image-box"><a><img src="/assets/images/clients/1.png"></a></div>
                        </li>
                        <li>
                            <div class="image-box"><a><img src="/assets/images/clients/2.png"></a></div>
                        </li>
                        <li>
                            <div class="image-box"><a><img src="/assets/images/clients/3.png"></a></div>
                        </li>
                        <li>
                            <div class="image-box"><a><img src="/assets/images/clients/4.png"></a></div>
                        </li>
                        <li>
                            <div class="image-box"><a><img src="/assets/images/clients/1.png"></a></div>
                        </li>
                        <li>
                            <div class="image-box"><a><img src="/assets/images/clients/2.png"></a></div>
                        </li>
                        <li>
                            <div class="image-box"><a><img src="/assets/images/clients/3.png"></a></div>
                        </li>
                        <li>
                            <div class="image-box"><a><img src="/assets/images/clients/4.png"></a></div>
                        </li>
                    </ul>
                </div>
            </div>
        </section>
        <!--End Sponsors Section-->

        <!--Subscribe Style One-->
        <section class="subscribe-style-one">
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="col-md-8 col-sm-12 col-xs-12">
                        <h2>Souscrire aux Newsletters</h2>
                        <div class="text">Entrer votre e-mail pour en savoir plus et rester en contact avec l'équipe
                            AidNov™</div>
                    </div>
                    <div class="col-md-4 col-sm-12 col-xs-12">
                        <form method="post" action="contact.html">
                            <div class="form-group">
                                <input type="email" name="email" value="" placeholder="Entrer votre e-mail" required>
                                <button type="submit" class="theme-btn"><span
                                        class="icon flaticon-send-message-button"></span></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
        <!--End Subscribe Style One-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/frontendother', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ProjectF\resources\views/frontend/temoignages.blade.php ENDPATH**/ ?>