<?php $__env->startComponent('mail::message'); ?>
## Bonjour 
<?php if($data['sex'] == 'M'): ?>
M. <?php echo e($data['name']); ?> <?php echo e($data['first_name']); ?>

<?php else: ?>
Mme <?php echo e($data['name']); ?> <?php echo e($data['first_name']); ?>

<?php endif; ?>

Bienvenue à <?php echo e(config('app.name')); ?>  votre Inscription a bien été éfectué.
Nous sommes Heureux de vous compter parmi nous.

<?php $__env->startComponent('mail::button', ['url' => url("/")]); ?>
Retour sur la plateforme
<?php echo $__env->renderComponent(); ?>

Merci,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\wamp64\www\sanguinproject\resources\views/emails/InscriptionSanguin.blade.php ENDPATH**/ ?>