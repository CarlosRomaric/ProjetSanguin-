<?php $__env->startSection('content'); ?>

    <div class="container">
      <header>
              <h3>Bienvenu Sur la plateforme de universelle de Don de Sang</h3>
      </header>
      <section>
      <?php if(!empty($message)): ?>
            <div class="alert alert-success">
                    <?php echo e($message); ?>

            </div>
      <?php endif; ?>
               
                    <a href="<?php echo e(route('member.create')); ?>" class="btn btn-primary">S'inscrire</a>
                    <a href="<?php echo e(route('member.index')); ?>" class="btn btn-dark">Liste des Inscrits</a>
               
      </section>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sanguinproject\resources\views/main/index.blade.php ENDPATH**/ ?>