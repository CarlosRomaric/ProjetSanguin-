<?php $__env->startSection('content'); ?>

     <!--Donate Section-->
        <section class="donate-section">
            <div class="auto-container">
                <!--Donate Block-->
                <div class="donate-block">
                    <div class="row clearfix">
                        <!--Image Column-->
                        <div class="image-column col-md-6 col-sm-12
                                        col-xs-12">
                        </div>
                        <!--Content Column-->
                    </div>
                </div>
                <div class="donate-form-section">
                    <div class="donation-form-outer">
                        <form method="post" action="contact.html" id="ambassadeur">

                            <h3>Devenir un Ambassadeur AidNov™ </h3>
                            <div class="sidebar-page-container
                                            blog-page">
                                <div class="auto-container">
                                    <div class="row clearfix">
                                        <!--Content Side-->
                                        <div class="content-side
                                                        col-lg-6 col-md-6
                                                        col-sm-6 col-xs-12">
                                            <!--News Block-->
                                            <div class="news-block">
                                                <div class="contact-form">
                                                    <div class="row
                                                                    clearfix">
                                                        <div class="form-group
                                                                        col-lg-6
                                                                        col-md-6
                                                                        col-xs-12">
                                                            <div class="field-label">Votre nom<span
                                                                    class="required">*</span>
                                                            </div>
                                                            <input id="nom" type="text" name="name" value=""
                                                                placeholder="Entrer votre nom" required>
                                                        </div>

                                                        <div class="form-group
                                                                        col-lg-6
                                                                        col-md-6
                                                                        col-xs-12">
                                                            <div class="field-label">Votre prénom(s)
                                                                <span class="required">*</span></div>
                                                            <input type="text" id="prenom" name="name" value=""
                                                                placeholder="Entrer votre prénom(s)" required>
                                                        </div>
                                                    </div>
                                                    <div class="row
                                                                    clearfix">
                                                        <div class="form-group
                                                                        col-lg-6
                                                                        col-md-6
                                                                        col-xs-12">
                                                            <div class="field-label">Votre
                                                                E-mail<span class="required">*</span></div>
                                                            <input id="email" type="email" name="name" value=""
                                                                placeholder="Entrer votre e-mal" required>
                                                        </div>
                                                        <div class="form-group
                                                                        col-lg-6
                                                                        col-md-6
                                                                        col-xs-12">
                                                            <div class="field-label">Numéro
                                                                de
                                                                téléphone<span class="required">*</span></div>
                                                            <input id="num" type="text" name="name" value=""
                                                                placeholder="Entrer votre numéro de téléphone" required>
                                                        </div>
                                                    </div>

                                                    <div class="row
                                                                    clearfix">
                                                        <div class="form-group
                                                                        col-lg-6
                                                                        col-md-6
                                                                        col-xs-12">
                                                            <div class="field-label">Votre pays<span
                                                                    class="required">*</span></div>
                                                            <select name="country"
                                                                class="countries select-2 order-alpha presel-CI"
                                                                id="countryId">
                                                                <option value="no">Choisir votre pays</option>
                                                            </select>
                                                        </div>
                                                        <div class="form-group
                                                                        col-lg-6
                                                                        col-md-6
                                                                        col-xs-12">
                                                            <div class="field-label">Votre Département<span
                                                                    class="required">*</span></div>
                                                            <select name="state" class="states select-2 order-alpha"
                                                                id="stateId">
                                                                <option value="no">Sélectionner votre département
                                                                </option>
                                                            </select>
                                                        </div>
                                                    </div>

                                                    <div class="row
                                                                    clearfix">
                                                        <div class="form-group
                                                                        col-lg-6
                                                                        col-md-6
                                                                        col-xs-12">
                                                            <div class="field-label">Votre ville<span
                                                                    class="required">*</span></div>
                                                            <select name="city" class="cities select-2 order-alpha"
                                                                id="cityId">
                                                                <option value="no">Sélectionner votre ville</option>
                                                            </select>
                                                        </div>

                                                        <div class="form-group
                                                                        col-lg-6
                                                                        col-md-6
                                                                        col-xs-12">
                                                            <div class="field-label">Votre
                                                                adresse postale</div>
                                                            <input id="adresse" type="text" name="name" value=""
                                                                placeholder="Entrer votre adresse postale" required>
                                                        </div>
                                                    </div>
                                                    <div class="text-left"><button type="submit"
                                                            class="theme-btn btn-style-one1">Soumettre sa
                                                            demande</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!--Content Side-->
                                        <div class="content-side
                                                        col-lg-6 col-md-6
                                                        col-sm-6 col-xs-12">
                                            <!--News Block-->
                                            <div>
                                                <div>
                                                    <div>
                                                        <h3>Vous Pouvez Aider Des Personnes En Difficultés</h3>
                                                        <div class="form-group
                                                                        col-lg-12
                                                                        col-md-12
                                                                        col-xs-12">
                                                            Être Ambassadeur AidNov™ chez LoHiDi<span
                                                                id="®">®</span> Group, c’est donner du temps et partager ses compétences, et ainsi aider à valider les campagnes sur la plateforme pour des initiatives de solidarité. 
                                                            <br> 
                                                            <br>C’est aussi rejoindre une communauté d’Ambassadeurs vivants et grandissants, et participer à des rencontres avec l’équipe! Vous avez envie de vous engager avec AidNov™ ? Nous vous attendons ! Remplissez le formulaire pour proposer votre appui Ambassadeur aux équipes supports et opérationnelles.</div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>

                                    <!-- Popular Tags -->
                                </div>
                            </div>

        </section>

        <!--End Donate Section-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/frontendother', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ProjectF\resources\views/frontend/ambassadeur.blade.php ENDPATH**/ ?>