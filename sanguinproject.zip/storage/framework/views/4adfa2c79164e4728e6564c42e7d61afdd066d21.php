<?php $__env->startSection('content'); ?>

        <!--Causes Section-->
        <section class="causes-section causes-grid-page">
            <div class="auto-container">
                <div class="row clearfix">

                    <!--Causes Block-->

                    <!--Causes Block-->
                    <a href="<?php echo e(route('causeBack.index')); ?>" class="btn btn-primary">Liste des causes</a>
                   <p class="text-center">
                        <h3>Enregistrer une cause</h3>
                   </p> 
                    <?php echo e($errors); ?>

                   <form action="<?php echo e(route('causeBack.store')); ?>" method="post">
                   <?php echo csrf_field(); ?>
                        <div class="form-group row">
                            <label for="libelle" class="col-md-3">Libelle</label>
                            <div class="col-md-9">
                                <input type="text"  name="libelle" class="form-control" id="libelle" placeholder="Enter le libelle de la cause">   
                            </div>
                        </div>

                        <!--<div class="form-group row">
                            <label for="descriptioncause" class="col-md-3">Description</label>
                            <div class="col-md-9">
                                <textarea  name="description" class="form-control" id="descriptioncause" placeholder="Enter une brève description"><textarea>  
                            </div>
                        </div>-->
                        <button type="submit" class="btn btn-success">Enregistrer</button>
                   </form>

                    
                    
                    
                    <!--Causes Block-->
                
                </div>
        </section>
        <!--End Causes Section-->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ProjectF\resources\views/causeBack/create.blade.php ENDPATH**/ ?>