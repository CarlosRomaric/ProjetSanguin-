[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH C:\wamp64\www\sanguinproject\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>