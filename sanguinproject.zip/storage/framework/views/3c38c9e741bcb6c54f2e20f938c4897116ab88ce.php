<tr>
    <td class="header">
        <a href="<?php echo e($url); ?>">  
          <!--<img src="http://localhost:8000/assets/images/logo.png" class="img-header"> -->
            <?php echo e(config('app.name')); ?>

            
        </a>
    </td>
</tr>
<?php /**PATH C:\wamp64\www\sanguinproject\resources\views/vendor/mail/html/header.blade.php ENDPATH**/ ?>