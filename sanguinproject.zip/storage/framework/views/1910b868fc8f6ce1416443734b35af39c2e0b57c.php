<?php $__env->startSection('content'); ?>
<div class="sidebar-page-container blog-page">
    <div class="auto-container">
      <div class="row clearfix">
            <?php $__currentLoopData = $campagnes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campagne): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="causes-block col-md-4 col-sm-6 col-xs-12">
                <div class="inner-box">
                    <div class="image">
                        <a href="<?php echo e(route('campagneDetail', $campagne->id)); ?>"><img src="/reduct/<?php echo e($campagne->photo); ?>" alt="" /></a>
                    </div>
                    <div class="lower-box">
                        <div class="content">
                            <h3><a href="<?php echo e(route('campagneDetail', $campagne->id)); ?>" id="textt"><?php echo e($campagne->titre); ?></a>
                            </h3>
                            <div class="text" id="textt"><?php echo e($campagne->description); ?></div>
                            <div class="donate-bar wow fadeIn" data-wow-delay="0ms" data-wow-duration="0ms">
                                <div class="bar-inner">
                                    <div class="bar" style="width:82%;">
                                        <div class="count-box"><span class="count-text" data-speed="2000"
                                                data-stop="82">0</span>%</div>
                                    </div>
                                </div>
                            </div>
                            <div class="causes-info"><strong>Recoltés</strong> 56.000 FCFA / <span
                                    class="theme_color"><?php echo e($campagne->montantObjectif); ?> FCFA</span></div>
                            
                            <div class="fb-share-button" data-href="https://developers.facebook.com/docs/plugins/" data-layout="button_count" data-size="large"><a target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fdevelopers.facebook.com%2Fdocs%2Fplugins%2F&amp;src=sdkpreparse" class="fb-xfbml-parse-ignore">Partager</a></div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
         <div class="text-center">   
                    <?php echo e($campagnes->links()); ?>

            </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-js'); ?>
<div id="fb-root"></div>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/fr_FR/sdk.js#xfbml=1&version=v7.0" nonce="wtuJ5pSe"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/frontendother', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ProjectF\resources\views/frontend/campagneFront.blade.php ENDPATH**/ ?>