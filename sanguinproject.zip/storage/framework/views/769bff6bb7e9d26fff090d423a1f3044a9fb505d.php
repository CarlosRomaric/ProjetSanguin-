<p class="text-center">
    <h3><strong>NB:</strong>Vous devez au préalable renseigner les causes, les Départements, les villes, les pays <br>
    afin de permettre au utlisateurs de démarrer une campagne
    </h3>
</p>
 <br><?php /**PATH C:\wamp64\www\ProjectF\resources\views/inc/info.blade.php ENDPATH**/ ?>