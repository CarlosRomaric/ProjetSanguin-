<!DOCTYPE html>
<!--[if IE 8 ]><html class="ie" xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!-->
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<!--<![endif]-->

<head>

    <!-- Basic Page Needs -->
    <meta charset="utf-8">

    <!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->

    <meta name="LoHiDi® Group" content="lohidi.com">
    <meta name="LoHiDi I IT®" content="it.lohidi.com">
    <meta name="LoHiDi I Creative®" content="creative.lohidi.com">
    <meta name="AidNov™">
    <meta name="#AIDONSNOUSVIVANT">

    <meta name="keywords"
        content="HTML, meta tag, tag reference, aide, donation, abidjan, aidons-nous, aidons, campagne, fonds, collecte de fonds, sante, famille, Commemoration, education, donate, famille, mariage, urgences, causes, crowdfunding, crowd, financement, financement participatif, collection, côte d'ivoire, aidons nous vivants, epidemie, lutter, pauvreté, religion, temoignages, financer, plateforme crowdfunding, project, afrique, africa, make a donation, realiser, entrepreneurs, crowdequity, crowdlending, prêt, investissement, ONG, ambassadeur, benevole, AidNov, LoHiDi® Group, LoHiDi I IT®, LoHiDi, facebook faire un don, aider une personne, #aidonsnousvivant, aidnov, démarrer un campagne, Faire un don, Devenir un Ambassadeur">


    <title>
    AidNov™ - A product of LoHiDi® Group :
	<br>La 1ère plateforme digitale de collecte de fonds au profit d'êtres et de causes qui vous sont chers.<br/>  
    </title>
    
    <!-- Stylesheets -->
    <link href="/assets/css/bootstrap.css" rel="stylesheet">
    <link href="/assets/css/revolution-slider.css" rel="stylesheet">
    <link href="/assets/css/style.css" rel="stylesheet">
    <link href="/assets/css/responsive.css" rel="stylesheet">

    <meta property="og:url"           content="http://localhost:8000/" />
    <meta property="og:type"          content="website" />
    <meta property="og:title"         content="Your Website Title" />
    <meta property="og:description"   content="Your description" />
    <meta property="og:image"         content="http://localhost:8000/assets/images/logo.png" />
    <!--Color Switcher Mockup-->
    <link href="/assets/css/color-switcher-design.css" rel="stylesheet">

    <!--Color Themes-->
    <link id="theme-color-file" href="/assets/css/color-themes/default-theme.css" rel="stylesheet">

    <!--Color Themes-->
    <link id="theme-color-file" href="/assets/css/color-themes/default-theme.css" rel="stylesheet">
    <!--Font-Awesome-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <!--Favicon-->
    <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
    <link rel="icon" href="images/favicon.ico" type="image/x-icon">

    <!-- Responsive -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

    <!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
    <!--[if lt IE 9]><script src="/assets/js/respond.js"></script><![endif]-->
    <style>
        .boxes-hover:hover {
            background-color: #bf4248 !important;
        }
    </style>

</head>

<body>
    <div class="page-wrapper">

        <!-- Preloader -->
        <div class="preloader"></div>

        <!-- Main Header-->
        <header class="main-header header-type-one">

            <!--Header Top-->
            <div class="header-top">
                <div class="auto-container">
                    <div class="clearfix">
                        <div class="top-left">
                            <ul class="clearfix">
                                <li><span class="icon fa fa-clock-o"></span> Lun-Sam: 8:00-17:00</li>

                                <li><span class="icon fa fa-envelope"></span><a href="mailto:aide@aidnov.com"
                                        target="_blank" style="color:#fff">aide@aidnov.com</a></li>
                            </ul>
                        </div>
                        <div class="top-right clearfix">
                            <ul class="social-icon-one">
                                <li><a href="<?php echo e(route('login')); ?>">Se connecter /</a>
                                    <a href="<?php echo e(route('register')); ?>">S'inscrire</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <!--Header-Upper-->
            <div class="header-upper">
                <div class="auto-container">
                    <div class="clearfix">
                        <div class="pull-left logo-outer">
                            <div class="logo"><a href="/"><img src="/assets/images/logo.png" alt="" title=""></a>
                            </div>
                        </div>
                        <div class="nav-outer clearfix">

                            <!-- Main Menu -->
                            <nav class="main-menu">
                                <div class="navbar-header">
                                    <!-- Toggle Button -->
                                    <button type="button" class="navbar-toggle" data-toggle="collapse"
                                        data-target=".navbar-collapse">
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                    </button>
                                </div>
                                <div class="navbar-collapse collapse clearfix">
                                   <?php echo $__env->make('inc/ulnavigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </nav>
                            <!-- Main Menu End-->

                            <!--Donate Btn-->
                            <div class="donate-btn">
                                <a class="donate theme-btn" href="<?php echo e(route('register')); ?>" id="demarre">Démarrer une
                                    campagne</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--End Header Upper-->

            <!--Sticky Header-->
            <div class="sticky-header">
                <div class="auto-container clearfix">
                    <!--Logo-->
                    <div class="logo pull-left">
                        <a href="/" class="img-responsive"><img src="/assets/images/logo-small.png" alt=""
                                title=""></a>
                    </div>

                    <!--Right Col-->
                    <div class="right-col pull-right">

                        <!-- Main Menu -->
                        <nav class="main-menu">
                            <div class="navbar-header">

                                <!-- Toggle Button -->
                                <button type="button" class="navbar-toggle" data-toggle="collapse"
                                    data-target=".navbar-collapse">
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                            </div>
                            <div class="navbar-collapse collapse clearfix">
                                <?php echo $__env->make('inc/ulnavigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        </nav>
                        <!--End Sticky Header-->

        </header>
        <!--End Main Header -->

        <!--Main Slider-->
        <section class="main-slider" data-start-height="700" data-slide-overlay="yes">

            <div class="tp-banner-container">
                <div class="tp-banner">
                    <ul>

                        <li data-transition="fade" data-slotamount="1" data-masterspeed="1000"
                            data-thumb="images/main-slider/Slide12.jpg" data-saveperformance="off"
                            data-title="Awesome Title Here">
                            <img src="/assets/images/main-slider/Slide12.jpg" alt="" data-bgposition="center top"
                                data-bgfit="cover" data-bgrepeat="no-repeat">

                            <div class="overlay-slide"></div>

                            <div class="tp-caption sfl sfb tp-resizeme" data-x="left" data-hoffset="15" data-y="center"
                                data-voffset="-60" data-speed="1500" data-start="0" data-easing="easeOutExpo"
                                data-splitin="none" data-splitout="none" data-elementdelay="0.01"
                                data-endelementdelay="0.3" data-endspeed="1200" data-endeasing="Power4.easeIn">
                                <h2>Des campagnes gratuites<br>aux profits d'êtres et de causes<br> qui vous sont
                                    chers.</h2>
                            </div>

                            <div class="tp-caption sfl sfb tp-resizeme" data-x="left" data-hoffset="15" data-y="center"
                                data-voffset="90" data-speed="1500" data-start="500" data-easing="easeOutExpo"
                                data-splitin="none" data-splitout="none" data-elementdelay="0.01"
                                data-endelementdelay="0.3" data-endspeed="1200" data-endeasing="Power4.easeIn">
                                <div class="text">Lancer une campagne dès aujourd'hui.</div>
                            </div>

                            <div class="tp-caption sfl sfb tp-resizeme" data-x="left" data-hoffset="15" data-y="center"
                                data-voffset="160" data-speed="1500" data-start="1000" data-easing="easeOutExpo"
                                data-splitin="none" data-splitout="none" data-elementdelay="0.01"
                                data-endelementdelay="0.3" data-endspeed="1200" data-endeasing="Power4.easeIn"><a
                                    href="<?php echo e(route('register')); ?>" class="theme-btn btn-style-two">Démarrer une
                                    campagne</a></div>

                        </li>

                        <li data-transition="fade" data-slotamount="1" data-masterspeed="1000"
                            data-thumb="images/main-slider/Slide4.jpg" data-saveperformance="off"
                            data-title="Awesome Title Here">
                            <img src="/assets/images/main-slider/Slide4.jpg" alt="" data-bgposition="center top"
                                data-bgfit="cover" data-bgrepeat="no-repeat">

                            <div class="tp-caption sft sfb tp-resizeme" data-x="center" data-hoffset="0" data-y="center"
                                data-voffset="-90" data-speed="1500" data-start="500" data-easing="easeOutExpo"
                                data-splitin="none" data-splitout="none" data-elementdelay="0.01"
                                data-endelementdelay="0.3" data-endspeed="1200" data-endeasing="Power4.easeIn">
                            </div>

                            <div class="tp-caption sfb sfb tp-resizeme" data-x="center" data-hoffset="0" data-y="center"
                                data-voffset="0" data-speed="1500" data-start="1000" data-easing="easeOutExpo"
                                data-splitin="none" data-splitout="none" data-elementdelay="0.01"
                                data-endelementdelay="0.3" data-endspeed="1200" data-endeasing="Power4.easeIn">
                                <h3>#AIDONSNOUSVIVANTS</h3>
                            </div>

                            <div class="tp-caption sfb sfb tp-resizeme" data-x="center" data-hoffset="15"
                                data-y="center" data-voffset="100" data-speed="1500" data-start="1500"
                                data-easing="easeOutExpo" data-splitin="none" data-splitout="none"
                                data-elementdelay="0.01" data-endelementdelay="0.3" data-endspeed="1200"
                                data-endeasing="Power4.easeIn"><a href="donate.html"
                                    class="theme-btn btn-style-two">Faire un don</a></div>
                        </li>
                    </ul>
                </div>
            </div>
        </section>
        <!--End Main Slider-->

        <!--Services Section-->
        <section class="services-section">
            <div class="auto-container">
                <!--Services Title-->
                <div class="services-title">
                    <h2>La plateforme<span> n°1 de collecte de fonds</span> pour des campagnes aux profits d'êtres et de
                        causes qui vous sont chers.</h2>
                    <div class="text">Leader de la collecte de fonds en ligne. </div>
                </div>
                <div class="clearfix">

                    <!--Services Style One-->
                    <div class="services-style-one col-md-4 col-sm-6 col-xs-12">
                        <div class="inner-box">
                            <div class="icon-box">
                                <span class="icon flaticon-donation"></span>
                            </div>
                            <h3><a href="<?php echo e(route('register')); ?>">Démarrer <br>une campagne</a></h3>
                            <div class="text">Il est maintenant facile de démarrer une cagnotte

                                solidaire pour collecter rapidement des fonds.</div>
                        </div>
                    </div>

                    <!--Services Style One-->
                    <div class="services-style-one col-md-4 col-sm-6 col-xs-12">
                        <div class="inner-box">
                            <div class="icon-box">
                                <span class="icon flaticon-piggy-bank"></span>
                            </div>
                            <h3><a href="cat%C3%A9gories_de_causes.html">Faire <br>un don</a></h3>
                            <div class="text">Il est maintenant facile de faire un don à un être

                                ou à des causes qui vous passionnent le plus.</div>
                        </div>
                    </div>

                    <!--Services Style One-->
                    <div class="services-style-one col-md-4 col-sm-6 col-xs-12">
                        <div class="inner-box">
                            <div class="icon-box">
                                <span class="icon flaticon-donation-1"></span>
                            </div>
                            <h3><a href="ambassadeur.html">Devenir <br>un Ambassadeur</a></h3>
                            <div class="text">Il est maintenant facile d’acquérir une perspective

                                unique en participant à nos différentes activités.</div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--End Services Section-->

        <!--FullWidth Section-->
        <section class="fullwidth-section">
            <div class="section-outer clearfix">
                <div class="image-column" style="background-image:url(/assets/images/resource/image-2.jpg);">
                    <div class="hidden-image"><img src="/assets/images/resource/image-2.jpg" alt=""></div>
                </div>
                <div class="content-column">
                    <div class="content">
                        <div class="title">PRINCIPALE COLLECTE DE FONDS</div>
                        <h2>Soutenir la plateforme digitale AidNov™</h2>
                        <div class="text">Le Covid-19 met notre jeune entreprise à rude épreuve. Même dans le meilleur des cas, il peut être difficile de survivre en tant que petite entreprise et nous sommes désormais confrontés à un avenir incertain. Nous avons donc mis en place une plateforme digitale permettant aux Ivoiriens de s'entraider entre eux de manière digitale. Nous vous invitons à la soutenir....</div>
                        <!--donate info-->
                        <div class="donate-info clearfix">
                            <div class="amount raised">Recoltés<span class="theme_color">3.560.350 FCFA</span></div>
                            <div class="amount goal">sur un objectif de <span class="theme_color">5.000.000
                                    FCFA</span></div>
                        </div>
                        <div class="donate-bar wow fadeIn" data-wow-delay="0ms" data-wow-duration="0ms">
                            <div class="bar-inner">
                                <div class="bar" style="width:73%;">
                                    <div class="count-box"><span class="count-text" data-speed="2000"
                                            data-stop="73">0</span>%</div>
                                </div>
                            </div>
                        </div>
                        <a href="donate.html" class="theme-btn btn-style-three">Faire un don</a>
                    </div>
                </div>
            </div>
        </section>
        <!--End FullWidth Section-->

        <!--Causes Section-->
        <section class="causes-section dark-bg">
            <div class="auto-container">
                <div class="sec-title clearfix">
                    <div class="pull-left">
                        <h2>Causes Récentes</h2>
                        <div class="text">Votre don apportera un sourire à quelqu'un.</div>
                    </div>
                </div>
                <div class="row clearfix">
                    <?php $__currentLoopData = $campagnes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campagne): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="causes-block col-md-4 col-sm-6 col-xs-12">
                        <div class="inner-box">
                            <div class="image">
                                <a href="<?php echo e(route('campagneDetail', $campagne->id)); ?>"><img src="/reduct/<?php echo e($campagne->photo); ?>" alt="" /></a>
                            </div>
                            <div class="lower-box">
                                <div class="content">
                                    <h3><a href="<?php echo e(route('campagneDetail', $campagne->id)); ?>" id="textt"><?php echo e($campagne->titre); ?></a>
                                    </h3>
                                    <div class="text" id="textt"><?php echo e($campagne->description); ?></div>
                                    <div class="donate-bar wow fadeIn" data-wow-delay="0ms" data-wow-duration="0ms">
                                        <div class="bar-inner">
                                            <div class="bar" style="width:82%;">
                                                <div class="count-box"><span class="count-text" data-speed="2000"
                                                        data-stop="82">0</span>%</div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="causes-info"><strong>Recoltés</strong> 56.000 FCFA / <span
                                            class="theme_color"><?php echo e($campagne->montantObjectif); ?></span></div>

                                    <div class="fb-share-button" data-href="https://developers.facebook.com/docs/plugins/" data-layout="button_count" data-size="large"><a target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fdevelopers.facebook.com%2Fdocs%2Fplugins%2F&amp;src=sdkpreparse" class="fb-xfbml-parse-ignore">Partager</a></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
               
                <?php if(($campagnes->count()!=0)): ?>
                <div class="text-center">       
                   <a href="<?php echo e(route('campagneFront')); ?>" class="theme-btn btn-style-one1">Toutes les causes</a>
                </div>
                <?php else: ?>
                <div class="text-center">       
                   Aucune cause n'est disponible pour le moment
                </div>
                <?php endif; ?>         
                    
            </div>
        </section>
        <!--End Causes Section-->

        <!--Default Section-->
        <section class="default-section">
            <div class="auto-container">
                <div class="row clearfix">

                    <!--About Column-->
                    <div class="about-column col-md-6 col-sm-12 col-xs-12">
                        <!--Sec Title-->
                        <div class="sec-title medium">
                            <h2>À propos</h2>
                        </div>
                        <div class="row clearfix">
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <h3>Qui sommes-nous ?</h3>
                                <div class="text">Au fond de nous, nous rêvons tous d’un monde meilleur. Une étincelle
                                    nous pousse à venir en aide à quelqu’un, à sauver un quartier ou même à changer une
                                    nation. Chez AidNov™, nous pensons qu’il faut partager votre inspiration avec tout
                                    le monde.</div>
                            </div>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <h3>Notre mission</h3>
                                <div class="text">Grâce à notre site, il est facile d’inspirer les autres et de
                                    transformer la compassion en actes. En donnant aux gens les outils dont ils ont
                                    besoin pour partager leur histoire avec le plus grand nombre.</div>
                                <!-- , nous avons bâti une
                                    communauté de plus de 50 millions de donateurs. -->
                            </div>
                        </div>
                        <div class="clearfix">
                            <!--Author Info-->
                            <div class="author-info pull-left">
                                <div class="img-thumb">
                                    <img src="/assets/images/resource/Joel 75x76.jpg" alt="" />
                                </div>
                                <h4>Joel S. P. Gnakale</h4>
                                <div class="designation">CEO & Founder LoHiDi<span id="®">®</span> Group</div>
                            </div>
                        </div>
                        <a href="a_propos.html" class="theme-btn btn-style-one1">En savoir plus</a>
                    </div>

                    <!--Accordian Column-->
                    <div class="accordian-column col-md-6 col-sm-12 col-xs-12">
                        <!--Sec Title-->
                        <div class="sec-title medium">
                            <h2>FAQ !</h2>
                        </div>
                        <ul class="accordion-box">

                            <!--Block-->
                            <li class="accordion block">
                                <div class="acc-btn">
                                    <div class="icon-outer"><span class="icon icon-plus flaticon-plus-symbol"></span>
                                        <span class="icon icon-minus flaticon-minus-symbol"></span></div>Comment
                                    démarrer une campagne ?
                                </div>
                                <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                            <p>Pour faire une campagne, cliquez sur le bouton <a href="<?php echo e(route('register')); ?>"
                                                    style="color:#bf4248 ;">démarrer une campagne</a>,
                                                remplissez le formulaire demandé et validez votre campagne.</p>
                                        </div>
                                    </div>
                                </div>
                            </li>

                            <!--Block-->
                            <li class="accordion block">
                                <div class="acc-btn active">
                                    <div class="icon-outer"><span class="icon icon-plus flaticon-plus-symbol"></span>
                                        <span class="icon icon-minus flaticon-minus-symbol"></span></div>Comment
                                    collecter des fonds?
                                </div>
                                <div class="acc-content current">
                                    <div class="content">
                                        <div class="text">
                                            <p>Pour collecter plus de don, veuillez faire la promotion de votre campagne
                                                en la partageant sur les réseaux sociaux et inciter plus de gens à vous
                                                aider</p>
                                        </div>
                                    </div>
                                </div>
                            </li>

                            <!--Block-->
                            <li class="accordion block">
                                <div class="acc-btn">
                                    <div class="icon-outer"><span class="icon icon-plus flaticon-plus-symbol"></span>
                                        <span class="icon icon-minus flaticon-minus-symbol"></span></div>Comment devenir
                                    un Ambassadeur?
                                </div>
                                <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                            <p>Pour devenir Ambassadeur AidNov™ et aider les personnes en manque,
                                                veuillez vous rendre sur la page <a href="ambassadeur.html"
                                                    style="color:#bf4248 ;">Devenir un Ambassadeur</a> et remplir le
                                                formulaire
                                                d'inscription.</p>
                                        </div>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <section class="team-section">
                <div class="auto-container">
                    <!--Sec Title-->
                    <div class="sec-title centered">
                        <h2>Notre équipe</h2>
                        <h3 style="color: black;">Une entreprise à grande vision</h3>
                        <div class="text">LoHiDi<span class="custom-trademark"><span id="®">®</span></span> Group a pour
                            objectif d'élaborer et d’apporter des solutions numériques afin de simplifier la vie de
                            tous.</div>
                    </div>
                    <div class="row clearfix">

                        <!--Team Member-->
                        <div class="team-member col-md-3 col-sm-6 col-xs-12">
                            <div class="inner-box">
                                <div class="image">
                                    <img src="/assets/images/resource/team-1.jpg" alt="" />
                                    <div class="overlay-box">
                                        <ul class="social-icon-four">
                                            <li><a href="https://www.linkedin.com/in/joel-s-p-gnakale-b48169194/"
                                                    target="_blank"><span class="fa fa-linkedin"></span></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="lower-box">
                                    <h3>Joël S. P. Gnakale</h3>
                                    <div class="designation">Chief Executive Officer</div>
                                </div>
                            </div>
                        </div>
                        <div class="team-member col-md-3 col-sm-6 col-xs-12">
                            <div class="inner-box">
                                <div class="image">
                                    <img src="/assets/images/resource/team-7.jpg" alt="" />
                                    <div class="overlay-box">
                                        <ul class="social-icon-four">
                                            <li><a href="https://www.linkedin.com/in/sahi-ibrahim-soumahoro-4972488a/"
                                                    target="_blank"><span class="fa fa-linkedin"></span></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="lower-box">
                                    <h3>Ibrahim Soumahoro</h3>
                                    <div class="designation">Chief Technology Officer</div>
                                </div>
                            </div>
                        </div>

                        <div class="team-member col-md-3 col-sm-6 col-xs-12">
                            <div class="inner-box">
                                <div class="image">
                                    <img src="/assets/images/resource/Abiba 2.jpg" alt="" />
                                    <div class="overlay-box">
                                        <ul class="social-icon-four">
                                            <li><a href="https://www.linkedin.com/" target="_blank"><span
                                                        class="fa fa-linkedin"></span></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="lower-box">
                                    <h3>Habiba D. Ouattara</h3>
                                    <div class="designation">Assistant of The CEO & Founder</div>
                                </div>
                            </div>
                        </div>


                        <div class="team-member col-md-3 col-sm-6 col-xs-12">
                            <div class="inner-box">
                                <div class="image">
                                    <img src="/assets/images/resource/team-5.jpg" alt="" />
                                    <div class="overlay-box">
                                        <ul class="social-icon-four">
                                            <li><a href="https://www.linkedin.com/in/pascal-thibaud-101700149/"
                                                    target="_blank"><span class="fa fa-linkedin"></span></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="lower-box">
                                    <h3>Pascal O. Thibaud</h3>
                                    <div class="designation">Manager, Digital Solutions </div>
                                </div>
                            </div>
                        </div>

                        <div class="team-member col-md-3 col-sm-6 col-xs-12">
                            <div class="inner-box">
                                <div class="image">
                                    <img src="/assets/images/resource/team-3.jpg" alt="" />
                                    <div class="overlay-box">
                                        <ul class="social-icon-four">
                                            <li><a href="https://www.linkedin.com/in/serge-g-oue-08aba8196/"
                                                    target="_blank"><span class="fa fa-linkedin"></span></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="lower-box">
                                    <h3>Serge G. Oué</h3>
                                    <div class="designation">Manager, IT Solutions</div>
                                </div>
                            </div>
                        </div>
                        <!--Team Member-->
                        <div class="team-member col-md-3 col-sm-6 col-xs-12">
                            <div class="inner-box">
                                <div class="image">
                                    <img src="/assets/images/resource/team-2.jpg" alt="" />
                                    <div class="overlay-box">
                                        <ul class="social-icon-four">
                                            <li><a href="https://www.linkedin.com/in/chris-aka-635234181/"
                                                    target="_blank"><span class="fa fa-linkedin"></span></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="lower-box">
                                    <h3>Chris H. Aka </h3>
                                    <div class="designation">Intern, Web Developer</div>
                                </div>
                            </div>
                        </div>

                        <!--Team Member-->

                        <div class="team-member col-md-3 col-sm-6 col-xs-12">
                            <div class="inner-box">
                                <div class="image">
                                    <img src="/assets/images/resource/team-4.jpg" alt="" />
                                    <div class="overlay-box">
                                        <ul class="social-icon-four">
                                            <li><a href="https://www.linkedin.com/in/herve-wilfried-gnahore-2b1b94177/"
                                                    target="_blank"><span class="fa fa-linkedin"></span></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="lower-box">
                                    <h3>Wilfried H. Gnahore</h3>
                                    <div class="designation">Full Stack Developer </div>
                                </div>
                            </div>
                        </div>

                        <div class="team-member col-md-3 col-sm-6 col-xs-12">
                            <div class="inner-box">
                                <div class="image">
                                    <img src="/assets/images/resource/team-6.jpg" alt="" />
                                    <div class="overlay-box">
                                        <ul class="social-icon-four">
                                            <li><a href="https://www.linkedin.com/in/liliane-guede-909a381ab/"
                                                    target="_blank"><span class="fa fa-linkedin"></span></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="lower-box">
                                    <h3>Liliane A. Guede</h3>
                                    <div class="designation">Visual Designer</div>
                                </div>
                            </div>
                        </div>

                        <!--Team Member-->

                    </div>
                </div>
            </section>
        </section>
        <!--End Default Section-->

        <!--Counter Section-->
        <section class="counter-section" style="background-image:url(/assets/images/background/1.jpg);">
            <div class="auto-container">
                <div class="row clearfix">

                    <div class="fact-counter">
                        <div class="row clearfix">

                            <!--Column-->
                            <!--Column-->
                            <div class="column counter-column wow fadeIn col-md-3 col-sm-6 col-xs-12"
                                data-wow-delay="0ms" data-wow-duration="0ms">
                                <div class="inner">

                                    <div class="count-outer count-box">
                                        <span class="count-text" data-speed="2500" data-stop="1479">0</span>
                                    </div>
                                    <h4 class="counter-title">Campagnes Completées</h4>
                                </div>
                            </div>

                            <div class="column counter-column wow fadeIn col-md-3 col-sm-6 col-xs-12"
                                data-wow-delay="0ms" data-wow-duration="0ms">
                                <div class="inner">

                                    <div class="count-outer count-box">
                                        <span class="dollor-sign"></span>
                                        <span class="count-text" data-speed="6000" data-stop="388.631">0</span>FCFA
                                    </div>
                                    <h4 class="counter-title">Dons collectés</h4>
                                </div>
                            </div>

                            <div class="column counter-column wow fadeIn col-md-3 col-sm-6 col-xs-12"
                                data-wow-delay="0ms" data-wow-duration="0ms">
                                <div class="inner">

                                    <div class="count-outer count-box">
                                        <span class="dollor-sign"></span>
                                        <span class="count-text" data-speed="6000" data-stop="388.631">0</span>FCFA
                                    </div>
                                    <h4 class="counter-title">Fonds attribués</h4>
                                </div>
                            </div>

                            <!--Column-->
                            <div class="column counter-column wow fadeIn col-md-3 col-sm-6 col-xs-12"
                                data-wow-delay="0ms" data-wow-duration="0ms">
                                <div class="inner">

                                    <div class="count-outer count-box">
                                        <span class="count-text" data-speed="3000" data-stop="2560">0</span>
                                        <span class="plus-tag">+</span>
                                    </div>
                                    <h4 class="counter-title">Ambassadeurs</h4>
                                </div>
                            </div>

                            <!--Column-->

                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--End Counter Section-->

        <!--Testimonial Section Two-->
        <section class="testimonial-section-two">
            <div class="auto-container">
                <h2>Témoignages!!</h2>
                <div class="three-item-carousel owl-carousel owl-theme">

                    <!--Testimonial Block Two-->
                    <div class="testimonial-block-two">
                        <div class="inner-box">
                            <div class="content">
                                <div class="author">
                                    <div class="image">
                                        <img src="/assets/images/resource/author-5.jpg" alt="" />
                                    </div>
                                    <h3>Bénédicte Tra lou</h3>
                                    <div class="designation">De la Côte d'ivoire</div>
                                </div>
                                <div class="text">J'aime cette plateforme, elle me permet de faire des dons sans me
                                    déplacer.</div>
                                <div class="clearfix">
                                    <div class="pull-left">
                                        <div class="date">01 juin 2020</div>
                                    </div>
                                    <div class="pull-right">
                                        <div class="quote-icon"><span class="flaticon-left-quote-1"></span></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!--Testimonial Block Two-->
                    <div class="testimonial-block-two">
                        <div class="inner-box">
                            <div class="content">
                                <div class="author">
                                    <div class="image">
                                        <img src="/assets/images/resource/author-6.jpg" alt="" />
                                    </div>
                                    <h3>Rashed Kabir</h3>
                                    <div class="designation">Du Maroc</div>
                                </div>
                                <div class="text">AidNov est géniale, redonnez du sourire au gens en besoin depuis
                                    l'autre coté du monde.</div>
                                <div class="clearfix">
                                    <div class="pull-left">
                                        <div class="date">28 jan 2020</div>
                                    </div>
                                    <div class="pull-right">
                                        <div class="quote-icon"><span class="flaticon-left-quote-1"></span></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!--Testimonial Block Two-->
                    <div class="testimonial-block-two">
                        <div class="inner-box">
                            <div class="content">
                                <div class="author">
                                    <div class="image">
                                        <img src="/assets/images/resource/author-7.jpg" alt="" />
                                    </div>
                                    <h3>Muhibbur Rashid</h3>
                                    <div class="designation">From Accra</div>
                                </div>
                                <div class="text">Super, c'est sécurisé et rapide. Très belle initiative, chapeau a
                                    l'équipe LoHiDi Group..</div>
                                <div class="clearfix">
                                    <div class="pull-left">
                                        <div class="date">14 Avril 2020</div>
                                    </div>
                                    <div class="pull-right">
                                        <div class="quote-icon"><span class="flaticon-left-quote-1"></span></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--End Testimonial Section Two-->

        <!--Call To Action Section-->
        <section class="call-to-action-section" style="background-image:url(/assets/images/background/2.jpg);">
            <div class="auto-container">
                <h2>Devenir un Ambassadeur</h2>
                <div class="text">Rejoignez-nous, devenez un héros et faites sourire le monde !!</div>
                <a href="ambassadeur.html" class="theme-btn btn-style-three">Devenir un Ambassadeur</a>
            </div>
        </section>
        <!--End Call To Action Section-->

        <!--News Section-->
        <section class="news-section">
            <div class="auto-container">

                <div class="sec-title clearfix">
                    <div class="pull-left">
                        <h2>Nouvelles récentes</h2>
                    </div>
                </div>
                <div class="row clearfix">

                    <!--Column-->
                    <div class="column col-md-8 col-sm-12 col-xs-12">
                        <div class="row clearfix">

                            <!--News Block-->
                            <div class="news-block col-md-6 col-sm-6 col-xs-12">
                                <div class="inner-box">
                                    <div class="image">
                                        <a href="education.html"><img src="/assets/images/resource/news-1.jpg" alt="" /></a>
                                    </div>
                                    <div class="lower-box">
                                        <h3>L'éducation des enfants en Afrique du Sud
                                            !!!!</h3>
                                        <div class="text">Des enfants en Afrique du Sud ont besoin d'aide pour être
                                            scolarisés</div>
                                    </div>
                                </div>
                            </div>

                            <!--News Block-->
                            <div class="news-block col-md-6 col-sm-6 col-xs-12">
                                <div class="inner-box">
                                    <div class="image">
                                        <a href="ambassadeur.html"><img src="/assets/images/resource/news-2.jpg" alt="" /></a>
                                    </div>
                                    <div class="lower-box">
                                        <h3>Devenir un Ambassadeur</h3>
                                        <div class="text">Devenez ambassadeur maintenant et redonnez toujours du sourire
                                            au monde</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--Column-->
                    <div class="column col-md-4 col-sm-12 col-xs-12">
                        <!--News Block Two-->
                        <div class="news-block-two">
                            <div class="inner-box boxes-hover">
                                <h3><a href="education.html">Éducation pour tous</a></h3>
                                <div class="text">Nous primons l'éducation pour tous les enfants du monde</div>
                            </div>
                        </div>

                        <!--News Block Two-->
                        <div class="news-block-two">
                            <div class="inner-box boxes-hover">
                                <h3><a href="urgences.html">Sauvons les animaux</a></h3>
                                <div class="text">Non contre l'exploitation des animaux par des tierces personnes.</div>
                            </div>
                        </div>

                        <!--News Block Two-->
                        <div class="news-block-two">
                            <div class="inner-box boxes-hover">
                                <h3><a href="sante.html">Votre aide peut...</a></h3>
                                <div class="text">Nous sommes prêt a aider quel que soit le besoin d'une personne.</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--End News Section-->

        <!--Sponsors Section-->
        <section class="sponsors-section">
            <div class="auto-container">
                <div class="carousel-outer">
                    <!--Sponsors Slider-->
                    <ul class="sponsors-carousel owl-carousel owl-theme">
                        <li>
                            <div class="image-box"><a><img src="/assets/images/clients/1.png"></a></div>
                        </li>
                        <li>
                            <div class="image-box"><a><img src="/assets/images/clients/2.png"></a></div>
                        </li>
                        <li>
                            <div class="image-box"><a><img src="/assets/images/clients/3.png"></a></div>
                        </li>
                        <li>
                            <div class="image-box"><a><img src="/assets/images/clients/4.png"></a></div>
                        </li>
                        <li>
                            <div class="image-box"><a><img src="/assets/images/clients/1.png"></a></div>
                        </li>
                        <li>
                            <div class="image-box"><a><img src="/assets/images/clients/2.png"></a></div>
                        </li>
                        <li>
                            <div class="image-box"><a><img src="/assets/images/clients/3.png"></a></div>
                        </li>
                        <li>
                            <div class="image-box"><a><img src="/assets/images/clients/4.png"></a></div>
                        </li>
                    </ul>
                </div>
            </div>
        </section>
        <!--End Sponsors Section-->

        <!--Subscribe Style One-->
        <section class="subscribe-style-one">
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="col-md-8 col-sm-12 col-xs-12">
                        <h2>Souscrire aux Newsletters</h2>
                        <div class="text">Entrer votre e-mail pour en savoir plus et rester en contact avec l'équipe
                            AidNov™.</div>
                    </div>
                    <div class="col-md-4 col-sm-12 col-xs-12">
                        <form method="post" action="contact.html">
                            <div class="form-group">
                                <input type="email" name="email" value="" placeholder="Entrer votre e-mail" required>
                                <button type="submit" class="theme-btn"><span
                                        class="icon flaticon-send-message-button"></span></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
        <!--End Subscribe Style One-->

       <!--Main Footer-->
    <footer class="main-footer">
        <div class="auto-container">
            <div class="row clearfix">

                <!--big column-->
                <div class="big-column col-md-7 col-sm-12 col-xs-12">
                    <div class="row clearfix">

                        <!--Footer Column-->
                        <div class="footer-column col-md-6 col-sm-6 col-xs-12">
                            <div class="footer-widget logo-widget">
                                <div class="widget-content">
                                    <div class="logo-box">
                                        <a href="/"><img src="/assets/images/footer-logo.png" alt="" /></a>
                                    </div>
                                    <div class="text">La plateforme n°1 de collecte de fonds en ligne pour des
                                        campagnes au profit d'êtres et de causes qui vous sont chers. </div>
                                    <ul class="social-icon-two">
                                        <li><a href="https://www.facebook.com/aidnov" target="_blank"><span class="fa fa-facebook"></span></a></li>
                                        <li><a href="  https://www.instagram.com/aidnov_/" target="_blank"><span class="fa fa-instagram"></span></a></li>
                                        <li><a href="https://www.twitter.com/AidNov" target="_blank"><span class="fa fa-twitter"></span></a></li>
                                        <li><a href="https://www.youtube.com/channel/UCDdh2VwSi7EFndb6dqpuSMA" target="_blank"><span class="fa fa-youtube"></span></a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <!--Footer Column / Links Widget-->
                        <div class="footer-column col-md-6 col-sm-6 col-xs-12">
                            <div class="footer-widget links-widget">
                                <h2>Liens rapides</h2>
                                <div class="widget-content">
                                    <div class="row clearfix">
                                        <ul class="list col-md-7 col-sm-6 col-xs-12">
                                            <li><a href="a_propos.html">À propos </a></li>
                                            <li><a href="mode_d'emploi.html">Mode d'emploi </a></li>
                                            <li><a href="cat%C3%A9gories_de_causes.html">Causes</a></li>
                                            <li><a href="<?php echo e(route('register')); ?>">Démarrer une campagne</a></li>
                                            <li><a href="cat%C3%A9gories_de_causes.html">Faire un don</a></li>
                                        </ul>
                                            <ul class="list col-md-5 col-sm-6 col-xs-12">
                                                <li><a href="ambassadeur.html">Devenir un Ambassadeur</a></li>
                                                <li><a href="temoignages.html">Témoignages</a></li>
                                                <li><a href="https://www.apple.com/ios/app-store/">iOS App</a></li>
                                                <li><a href="https://play.google.com/store/apps">Android App</a></li>
                                                <li><a href="contact.html">Contact</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!--big column-->
                    <div class="big-column col-md-5 col-sm-12 col-xs-12">
                        <div class="row clearfix">

                            <!--Footer Column-->
                            <div class="footer-column col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                <div class="footer-widget gallery-widget">
                                    <h2>L'équipe</h2>
                                    <div class="widget-content">
                                        <div class="images-outer clearfix">
                                            <!--Image Box-->
                                            <figure class="image-box"><img src="/assets/images/gallery/footer-gallery-thumb-1.jpg" alt=""></figure>
                                            <figure class="image-box"><img src="/assets/images/gallery/footer-gallery-thumb-2.jpg" alt=""></figure>
                                            <figure class="image-box"><img src="/assets/images/gallery/footer-gallery-thumb-3.jpg" alt=""></figure>
                                            <figure class="image-box"><img src="/assets/images/gallery/footer-gallery-thumb-4.jpg" alt=""></figure>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!--Footer Column-->
                            <div class="footer-column col-md-6 col-sm-6 col-xs-12">
                                <div class="footer-widget address-widget">
                                    <h2>Contact</h2>
                                    <div class="widget-content">
                                        <ul class="list-style-one">
                                            <li><span class="icon flaticon-location-pin"></span>B54, Rue du Lycée Technique Cocody, Abidjan</li>
                                            <li><span class="icon fa fa-clock-o"></span> Lun-Sam: 8:00-17:00</li>
                                            <li><span class="icon flaticon-e-mail-envelope"></span><a href="mailto:aide@aidnov.com" style="color: rgb(160, 170, 179);" target="_blank">aide@aidnov.com</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            <!--Footer Bottom-->
            <div class="footer-bottom">
                <div class="auto-container">
                    <div class="row clearfix">
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="copyright"> © 2020 AidNov™ – A product of LoHiDi<span
                                    class="custom-trademark"><span id="®">®</span></span> Group. Tous droits
                                réservés.<br>Développé avec ❤️ à Abidjan, Côte d’Ivoire 🇨🇮 par <a
                                    href="https://it.lohidi.com" target="_blank" id="lien" style="color: #fff;"> LoHiDi
                                    I IT<span id="®">®</span></a></div></div>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <ul class="footer-nav">
                                <li><a href="https://drive.google.com/file/d/1ear0aODVdu8ew042SOXMM0MQ9ljYDrPn/view?usp=sharing"
                                        target="_blank">Conditions générales d'utilisation</a></li>
                                <li><a href="https://drive.google.com/file/d/1EYm7Hg4i2_qOxnh0_kAnuLUiuA-zU5Kg/view?usp=sharing"
                                        target="_blank">Politique de confidentialité</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
    <!--End pagewrapper-->

    <!--Scroll to top-->
    <div class="scroll-to-top scroll-to-target" data-target=".main-header">
    <span class="icon fa fa-long-arrow-up"></span></div>
    <script src="/assets/js/jquery.js"></script>
    <script src="/assets/js/bootstrap.min.js"></script>
    <script src="/assets/js/revolution.min.js"></script>
    <script src="/assets/js/jquery.fancybox.pack.js"></script>
    <script src="/assets/js/jquery.fancybox-media.js"></script>
    <script src="/assets/js/owl.js"></script>
    <script src="/assets/js/appear.js"></script>
    <script src="/assets/js/wow.js"></script>
    <script src="/assets/js/script.js"></script>
    <script src="/assets/js/color-settings.js"></script>
    <div id="fb-root"></div>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/fr_FR/sdk.js#xfbml=1&version=v7.0" nonce="wtuJ5pSe"></script><?php /**PATH C:\wamp64\www\ProjectF\resources\views/frontend/index2.blade.php ENDPATH**/ ?>