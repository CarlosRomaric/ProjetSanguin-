<?php $__env->startSection('content'); ?>

        <!--Sidebar Page Container-->
        <div class="sidebar-page-container blog-page">
            <div class="auto-container">
                <div class="row clearfix">

                    <!--Content Side-->
                    <div class="content-side col-lg-6 col-md-6 col-sm-6 col-xs-6">

                        <!--News Block-->
                        <div class="news-block">
                            <div class="inner-box">
                                <div class="image">
                                    <img src="/assets/images/resource/news-3.jpg" alt="" />
                                </div>

                            </div>
                        </div>

                        <!-- Styled Pagination -->
                        <div class="styled-pagination">
                            <ul class="clearfix">
                            </ul>
                        </div>
                    </div>
                    <!--Content Side-->
                    <div class="content-side col-lg-6 col-md-6 col-sm-6 col-xs-6">

                        <!--News Block-->
                        <div class="news-block">
                            <div class="inner-box">
                                <div class="lower-box">
                                    <h3>Idées de Cagnottes Gratuites et Faciles</h3>
                                    <div class="text">Démarquez-vous avec une cagnotte s’inspirant d’idées originales.
                                        Si vous voulez un guide regroupant des idées qui ont su attirer l’attention des
                                        donateurs, les inciter à faire un don et vous permettront de promouvoir votre
                                        cagnotte en la partageant sur les réseaux sociaux au sein de votre votre
                                        communauté veuillez nous contacter par formulaire sur la page "contact".
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

                <!-- Popular Tags -->
            </div>
        </div>

        <!--End Causes Section-->

        <!--Subscribe Style One-->
        <section class="subscribe-style-one">
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="col-md-8 col-sm-12 col-xs-12">
                        <h2>Souscrire aux Newsletters</h2>
                        <div class="text">Entrer votre e-mail pour en savoir plus et rester en contact avec l'équipe
                            AidNov™</div>
                    </div>
                    <div class="col-md-4 col-sm-12 col-xs-12">
                        <form method="post" action="contact.html">
                            <div class="form-group">
                                <input type="email" name="email" value="" placeholder="Entrer votre e-mail" required>
                                <button type="submit" class="theme-btn"><span
                                        class="icon flaticon-send-message-button"></span></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
        <!--End Subscribe Style One-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/frontendother', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ProjectF\resources\views/frontend/idees_pour_collecter.blade.php ENDPATH**/ ?>