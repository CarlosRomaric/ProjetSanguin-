  

  <?php $__env->startSection('content'); ?>
  <div class="page-wrapper">

		<!-- Preloader -->
		<div class="preloader"></div>

		<!-- Main Header-->
		<header class="main-header header-type-one">

			<!--Header Top-->
			<div class="header-top">
				<div class="auto-container">
					<div class="clearfix">
						<div class="top-left">
							<ul class="clearfix">
								<li><span class="icon fa fa-clock-o"></span> Lun-Sam: 8:00-17:00</li>
								<li><span class="icon fa fa-envelope"></span><a href="mailto:aide@aidnov.com"
										target="_blank" style="color:#fff">aide@aidnov.com</a></li>
							</ul>
						</div>

					</div>
				</div>
			</div>

			<!--Header-Upper-->
			<div class="header-upper">
				<div class="auto-container">
					<div class="clearfix">
						<div class="pull-left logo-outer">
							<div class="logo"><a href="/"><img src="/assets/images/logo.png" alt="" title=""></a></div>
						</div>
						<div class="nav-outer clearfix">

							<!-- Main Menu -->
							<nav class="main-menu">
								<div class="navbar-header">
								</div>
							</nav>

							<!-- Main Menu End-->

						</div>
					</div>
				</div>
			</div>

			<!--End Sticky Header-->
		</header>
		<style type="text/css">
			#® {

				font-size: 8px;

				vertical-align: top;

			}



			#®® {

				font-size: 18px;

				vertical-align: top;

			}

			#®®® {

				font-size: 17px;

				vertical-align: 44px;

			}

			body {
				color: #999;
				background: #f5f5f5;
				font-family: 'Roboto', sans-serif;
			}

			.form-control,
			.form-control:focus,
			.input-group-addon {
				border-color: #e1e1e1;
				border-radius: 0;
			}

			.signup-form {
				width: 390px;
				margin: 0 auto;
				padding: 30px 0;
			}

			.signup-form h2 {
				color: #636363;
				margin: 0 0 15px;
				text-align: center;
			}

			.signup-form .lead {
				font-size: 14px;
				margin-bottom: 30px;
				text-align: center;
			}

			.signup-form form {
				border-radius: 1px;
				margin-bottom: 15px;
				background: #fff;
				border: 1px solid #f3f3f3;
				box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
				padding: 30px;
			}

			.signup-form .form-group {
				margin-bottom: 20px;
			}

			.signup-form label {
				font-weight: normal;
				font-size: 13px;
			}

			.signup-form .form-control {
				min-height: 38px;
				box-shadow: none !important;
				border-width: 0 0 1px 0;
			}

			.signup-form .input-group-addon {
				max-width: 42px;
				text-align: center;
				background: none;
				border-width: 0 0 0px 0;
				padding-left: 5px;
			}

			.signup-form .btn {
				font-size: 16px;
				font-weight: bold;
				background: #bf4248;
				border-radius: 3px;
				border: none;
				min-width: 140px;
				outline: none !important;
			}

			.signup-form .btn:hover,
			.signup-form .btn:focus {
				background: #179b81;
			}

			.signup-form a {
				color: #bf4248;
				text-decoration: none;
			}

			.signup-form a:hover {
				text-decoration: underline;
			}

			.signup-form .fa {
				font-size: 21px;
			}

			.signup-form .fa-paper-plane {
				font-size: 17px;
			}

			.signup-form .fa-check {
				color: #fff;
				left: 9px;
				top: 18px;
				font-size: 7px;
				position: absolute;
			}

			#btn-un {
				position: relative;
                padding: 10px 30px;
                line-height: 24px;
                color: #bf4248;
                font-size: 13px;
                font-weight: 700;
                background-color: #fff;
                border: 2px solid #ffb607;	
			}

			#btn-un:hover {
				color: #ffffff;
				background: #bf4248;
				border-color: #ffb607;
			}

			#lock {
				margin-right: -2px;
			}

			#lock2 {
				margin-right: 2px;
			}

			#lock3 {
				margin-right: 2px;
			}
		</style>
		
		<div class="signup-form">
		  	 <?php if(session('success')): ?>
		   		<div class="alert alert-success">
					<?php echo e(session('sucess')); ?>   
				</div>
		   	 <?php endif; ?>
			<form action="<?php echo e(route('register')); ?>" method="post" id="signup-form" >
              <?php echo csrf_field(); ?>
				<h2>S'inscrire</h2>

				<div class="contact-form">
					<div class="form-group">
						<div class="input-group">
							<span class="input-group-addon"><i class="fa fa-user"></i></span>
							<input value="<?php echo e(old('name')); ?>" type="text" class="form-control <?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" id="name" name="name" placeholder="Nom"
								required="required" data-validate-length-range="3" data-validate-words="1">
							<?php if($errors->has('name')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                            <?php endif; ?>
						</div>
					</div>
					<div class="form-group">
						<div class="input-group">
							<span class="input-group-addon"><i class="fa fa-user"></i></span>
							<input value="<?php echo e(old('first_name')); ?>" type="text" class="form-control <?php echo e($errors->has('first_name') ? ' is-invalid' : ''); ?>" id="first_name" name="first_name" placeholder="Prénoms"
								required="required" data-rule="required|min:3" data-validate-length-range="3"
								data-validate-words="1">
							<?php if($errors->has('first_name')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('first_name')); ?></strong>
                                    </span>
                            <?php endif; ?>
						</div>
					</div>
					<div class="form-group">
						<div class="input-group">
							<span class="input-group-addon"><i id="lock" class="fa fa-paper-plane"></i></span>
							<input value="<?php echo e(old('email')); ?>" type="email" class="form-control  <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?> email" id="email" name="email" placeholder="E-mail"
								required="required">
							<?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                            <?php endif; ?>
						</div>
					</div>
                    <div class="form-group">
						<div class="input-group">
							<span class="input-group-addon"><i id="lock" class="fa fa-phone"></i></span>
							<input value="<?php echo e(old('phone')); ?>" type="tel" class="form-control  <?php echo e($errors->has('phone') ? ' is-invalid' : ''); ?>" id="phone" name="phone" placeholder="Entrez votre numero de téléphone"
								required="required">
							<?php if($errors->has('phone')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('phone')); ?></strong>
                                    </span>
                            <?php endif; ?>
						</div>
					</div>
					<div class="form-group">
						<div class="input-group">
							<span class="input-group-addon"><i id="lock2" class="fa fa-lock"></i></span>
							<input value="<?php echo e(old('password')); ?>" type="password" class="form-control <?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" id="password" name="password"
								placeholder="Mot de passe" required="required" data-rule="required"
								data-validate-linked='password'>
							<?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                            <?php endif; ?>
						</div>
					</div>
					<div class="form-group">
						<div class="input-group">
							<span class="input-group-addon">
								<i class="fa fa-lock" id="lock3"></i>
								<i class="fa fa-check"></i>
							</span>
							<input value="<?php echo e(old('password_confirmation')); ?>" type="password" class="form-control <?php echo e($errors->has('password_confirmation') ? ' is-invalid' : ''); ?>" id="confirm_password" name="password_confirmation"
								placeholder="Saisir à nouveau votre mot de passe" data-validate-linked='password'
								required="required" data-rule="required">
							<?php if($errors->has('password_confirmation')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                                    </span>
                            <?php endif; ?>
						</div>
					</div>
				</div>
                <input  type="hidden" name="role" value="1">    
				<p class="medium text-center">En cliquant sur <strong>"S'inscrire"</strong> vous acceptez les <a
						href="https://drive.google.com/file/d/1ear0aODVdu8ew042SOXMM0MQ9ljYDrPn/view?usp=sharing"
						target="_blank">Conditions générales d’utilisation</a> et
					accusez réception de la <a
						href="https://drive.google.com/file/d/1EYm7Hg4i2_qOxnh0_kAnuLUiuA-zU5Kg/view?usp=sharing"
						target="_blank">Politique de confidentialité</a>
					à <strong>AidNov™</strong> – A product of LoHiDi<span id="®">®</span> Group.</p>
				<div class="form-group">
					<button type="submit" class="btn btn-block btn-lg" id="btn-un">S'inscrire</button>
				</div>
			</form>
			<div class="text-center">Vous avez un compte ? <a href="<?php echo e(route('login')); ?>">Se connecter</a>.</div>
		   
		</div>
		<br>
	</div>
	<!--End Subscribe Style One-->

	<!--Scroll to top-->
	<div class="scroll-to-top scroll-to-target" data-target=".main-header">
    <span class="icon fa fa-long-arrow-up"></span></div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ProjectF\resources\views/auth/register.blade.php ENDPATH**/ ?>