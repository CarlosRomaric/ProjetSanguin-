<?php $__env->startSection('content'); ?>
             <!--Page Title-->
        <section class="page-title" style="background-color: #376E50;">
            <div class="auto-container">
                <div class="inner-box">
                    <h3>Modifier une campagne</h3>
                </div>
            </div>
        </section>
        <!--End Page Title-->

        <!--Donate Section-->
        <section class="donate-section">
            <div class="auto-container">
                <!--Donate Block-->
                <div class="donate-block">
                    <div class="row clearfix">
                        <!--Image Column-->
                        <div class="image-column col-md-6 col-sm-12 col-xs-12">
                        </div>
                        <!--Content Column-->
                    </div>
                </div>
                <div class="donate-form-section">
                    <div class="donation-form-outer">
                    
                        <form method="post" action="<?php echo e(route('campagne.update', $campagne->id)); ?>" id="price-form" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                             <input type="hidden" name="_method" value="PATCH">
                            <!--Form Portlet-->
                            <div class="contact-form">
                                <h3>Indiquez votre objectif ici ?</h3>

                                <div class="row clearfix">
                                    <div class="form-group col-lg-8 col-md-12 col-xs-12 clearfix">
                                    </div>

                                    <div class="form-group col-lg-8 col-md-8 col-xs-12 padd-top-20">
                                        <input id="prix" class="other-amount" required type="text" onkeypress="chiffres(event)" name="montantObjectif"
                                            placeholder="Votre objectif en FCFA" id="amount" value="<?php echo e($campagne->montantObjectif); ?>">
                                    </div>
                                </div>
                            </div>

                            <br>

                            <div class="contact-form">

                                <h3>Indiquez les détails de votre campagne</h3>
                                <div class="row clearfix">
                                    <div class="form-group col-lg-4 col-md-4 col-xs-12">
                                        <div class="field-label">Votre cause<span class="required">*</span></div>
                                        <select class="select-2" name="cause_id">
                                         <option>Choississez votre cause</option>
                                          <?php $__currentLoopData = $causes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cause): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <option value="<?php echo e($cause->id); ?>"><?php echo e($cause->libelle); ?></option>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <!--<option>Santé</option>
                                            <option>Commémoration</option>
                                            <option>Urgences</option>
                                            <option>Religion</option>
                                            <option>Éducation</option>
                                            <option>Mariage</option>
                                            <option>Famille</option>-->
                                        </select>
                                    </div>
                                    <div class="form-group col-lg-4 col-md-6 col-xs-12">
                                        <div class="field-label">Titre de votre campagne<span class="required">*</span>
                                        </div>
                                        <input type="text" name="titre" value="<?php echo e($campagne->titre); ?>" id="campagne" placeholder="Donner un titre à votre campagne" required>
                                    </div>
                                </div>

                                
                                <div class="row clearfix">
                                    <div class="form-group col-lg-4 col-md-6 col-xs-12">
                                        <div class="field-label">Votre Pays<span class="required">*</span></div>

                                        <select name="pays_id" class="countries select-2 order-alpha presel-CI"
                                            id="countryId">
                                            <option value="no">Sélectionner votre pays</option>
                                           <?php $__currentLoopData = $pays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($p->id); ?>"><?php echo e($p->libelle); ?></option>
                                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="form-group col-lg-4 col-md-6 col-xs-12">
                                        <div class="field-label">Votre Département<span class="required">*</span></div>

                                        <select name="departement_id" class="states select-2" id="stateId">
                                            <option value="">Sélectionner votre département</option>
                                            <?php $__currentLoopData = $departements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <option value="<?php echo e($departement->id); ?>"><?php echo e($departement->libelle); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="form-group col-lg-4 col-md-6 col-xs-12">
                                        <div class="field-label">Votre Ville<span class="required">*</span></div>

                                        <select name="ville_id" class="cities select-2" id="cityId">

                                            <option value="">Sélectionner votre ville</option>
                                            <?php $__currentLoopData = $villes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ville): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($ville->id); ?> "><?php echo e($ville->libelle); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>

                                    </div>
                                </div>

                            </div>

                            <input type="hidden" name="verified" value="0">
                            <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">

                            <div class="imageupload panel panel-default">
                                <div class="file-tab panel-body">
                                    <label class="btn btn-default btn-file">
                                        <span>Ajouter des photos </span>
                                        <!-- The file is stored here. -->
                                        <input type="file" name="photo">
                                    </label>
                                    <button type="button" class="btn btn-default" style="margin: 0;">Enlever</button>
                                </div>
                                <!-- The URL is stored here. -->
                                <!--<input type="hidden" name="image-url">-->
                            </div>

                            <div class="contact-form">
                                <div class="row clearfix">
                                    <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                        <textarea name="description" id="description" placeholder="Expliquer votre histoire en integralité"><?php echo e($campagne->description); ?></textarea>
                                    </div>
                                </div>
                            </div>

                            <div style="margin-bottom: 20px;">
                                <h5 style="font-weight: 300; color: black;">AidNov™ prélève une commission de 5 % sur
                                    chaque don
                                    reçu. Le processeur des dons collecte une commission de 3.5 % ou de 2.9 % par don
                                    effectué via Mobile Money ou par Carte de crédit. En poursuivant, vous acceptez les
                                    <a href="https://drive.google.com/file/d/1ear0aODVdu8ew042SOXMM0MQ9ljYDrPn/view?usp=sharing"
                                        target="_blank" style="color: #bf4248;">Conditions générales
                                        d’utilisation</a> et accusez réception de la <a
                                        href="https://drive.google.com/file/d/1EYm7Hg4i2_qOxnh0_kAnuLUiuA-zU5Kg/view?usp=sharing"
                                        target="_blank" style="color: #bf4248;">Politique de confidentialité</a> à
                                    AidNov™ – A product
                                    of LoHiDi<span id="®">®</span> Group.</h5>
                            </div>

                            <div class="text-left">
                                <button type="submit" class="theme-btn btn-style-one1">Soumettre
                                    votre campagne
                                </button>
                            </div>

                        </form>
                    </div>
                

        </section>
        <!--End Donate Section-->

        <!--Subscribe Style One-->
        <section class="subscribe-style-one">
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="col-md-8 col-sm-12 col-xs-12">
                        <h2>Souscrire aux Newsletters</h2>
                        <div class="text">Entrer votre e-mail pour en savoir plus et rester en contact avec l'équipe
                            AidNov™.</div>
                    </div>
                    <div class="col-md-4 col-sm-12 col-xs-12">
                        <form method="post" action="contact.html">
                            <div class="form-group">
                                <input type="email" name="email" value="" placeholder="Entrer votre e-mail" required>
                                <button type="submit" class="theme-btn"><span
                                        class="icon flaticon-send-message-button"></span></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
        <!--End Subscribe Style One-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-js'); ?>
<script>
            //Autoriser que la saisie des chiffres
            function chiffres(event) {
                    // Compatibilité IE / Firefox
                    if(!event&&window.event) {
                    event=window.event;
                    }
                    // IE
                    if(event.keyCode < 48 || event.keyCode > 57 || event.keyCode  == 8 || event.keyCode == 127) {
                    event.returnValue = false;
                    event.cancelBubble = true;
                    }
                    // DOM
                    if(event.which < 48 || event.which > 57 || event.keyCode == 8 || event.keyCode == 127) {
                    event.preventDefault();
                    event.stopPropagation();
                    }
            }

    </script>
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ProjectF\resources\views/campagnes/edit.blade.php ENDPATH**/ ?>