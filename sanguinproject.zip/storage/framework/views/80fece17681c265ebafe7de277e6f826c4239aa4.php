<?php $__env->startSection('content'); ?>

        <!--Map Section-->
        <section class="map-section">
            <!--Map Outer-->
            <div class="map-outer">

                <!--Map Canvas-->

                <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3972.41923283468!2d-4.007852084708792!3d5.352815296117207!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xfc1ebc625e23881%3A0x6f6220726b98d057!2sLoHiDi%C2%AE%20Group%20SARL!5e0!3m2!1sen!2sci!4v1592271029882!5m2!1sen!2sci"
                    width="100%" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false"
                    tabindex="0"></iframe>

            </div>
        </section>
        <!--End Map Section-->

        <!--Contact Section-->
        <section class="contact-section">
            <div class="auto-container">
                <div class="row clearfix">

                    <!--Form Column-->
                    <div class="form-column col-md-7 col-sm-12 col-xs-12">
                        <h2>Envoyer un message</h2>
                        <div class="text">Si vous avez des questions, n'hésitez pas à communiquer avec un membre de
                            notre équipe.</div>
                        <!--Contact Form-->
                        <div class="contact-form">
                            <form method="post" action="https://t.commonsupport.xyz/huminity/sendemail.php" >
                                <div class="row clearfix">

                                    <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                        <input type="text" name="username" value=""
                                            placeholder="Entrer votre nom et prénom(s)">
                                    </div>

                                    <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                        <input type="email" name="email" value="" placeholder="Entrer votre e-mail">
                                    </div>

                                    <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                        <textarea name="message" placeholder="Saisir votre message..."></textarea>
                                    </div>

                                    <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                        <button type="submit" class="theme-btn btn-style-four">Envoyer votre
                                            message</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <!--End Contact Form-->

                    </div>

                    <!--Info Container-->
                    <div class="info-column col-md-5 col-sm-12 col-xs-12">
                        <div class="inner-column">
                            <h2>Contact</h2>
                            <ul class="contact-info">

                                <li>
                                    <div class="icon-box"><span class="flaticon-placeholder-1"></span></div>
                                    <h4>Address</h4>B54, Rue du Lycée Technique Cocody, Abidjan<br>
                                </li>

                                <li>
                                    <div class="icon-box"><span class="icon fa fa-clock-o "></span></div>
                                    <h4>Ouverture</h4>Lun-Sam: 8:00-17:00<br>
                                </li>

                                <li>
                                    <div class="icon-box"><span class="">@</span></div>
                                    <h4>E-mail</h4><a href="mailto:aide@aidnov.com" target="_blank"
                                        style="color: #bf4248">aide@aidnov.com</a>
                                </li>

                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--End Contact Section-->

        <!--Subscribe Style One-->
        <section class="subscribe-style-one">
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="col-md-8 col-sm-12 col-xs-12">
                        <h2>Souscrire aux Newsletters</h2>
                        <div class="text">Entrez votre e-mail pour en savoir plus et rester en contact avec l'équipe
                            AidNov™</div>
                    </div>
                    <div class="col-md-4 col-sm-12 col-xs-12">
                        <form method="post" action="">
                            <div class="form-group">
                                <input type="email" name="email" value="" placeholder="Entrer votre e-mail" required>
                                <button type="submit" class="theme-btn"><span
                                        class="icon flaticon-send-message-button"></span></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
        <!--End Subscribe Style One-->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-js'); ?>
    <script src="/assets/js/validate.js"></script>
    <!--Google Map APi Key-->
    <script src="http://maps.google.com/maps/api/js?key=AIzaSyBKS14AnP3HCIVlUpPKtGp7CbYuMtcXE2o"></script>
    <script src="/assets/js/map-script.js"></script>
    <!--End Google Map APi-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/frontendother', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ProjectF\resources\views/frontend/contact.blade.php ENDPATH**/ ?>