<?php $__env->startSection('content'); ?>
<!--Sidebar Page Container-->
            <div class="sidebar-page-container blog-page">
                <div class="auto-container">
                    <div class="row clearfix">

                        <!--Content Side-->
                        <div class="content-side col-lg-12 col-md-12 col-sm-12 col-xs-12">

                            <!--News Block-->
                            <div class="news-block">
                                <div class="inner-box">
                                    <div class="image">
                                        <img src="/assets/images/resource/conseil.jpg" alt="" />
                                    </div>

                                </div>
                            </div>

                            <!-- Styled Pagination -->
                            <div class="styled-pagination">
                                <ul class="clearfix">
                                </ul>
                            </div>
                        </div>
                        <!--Content Side-->
                        <div class="content-side col-lg-12 col-md-12 col-sm-12 col-xs-12">

                            <!--News Block-->
                            <section class="who-we-are-section">

                                <div class="auto-container">

                                    <div class="inner-container">

                                        <div class="row clearfix">

                                            <!--Services Style Two-->

                                            <div class="services-style-two col-md-4 col-sm-6 col-xs-12">

                                                <div class="inner-box">

                                                    <div class="block-number">01</div>

                                                    <h2><a href="creer_une_campagne.html">Démarrer <br>votre campagne</a></h2>

                                                    <div class="text">
                                                        <ul>
                                                            <li type="circle">&#8226; Définir l’objectif de votre campagne.</li>
                                                            <li type="circle">&#8226; Raconter votre histoire.</li>
                                                            <li type="circle">&#8226; Ajouter une photo ou une vidéo.
                                                            </li>
                                                        </ul>
                                                    </div>

                                                </div>

                                            </div>



                                            <!--Services Style Two-->

                                            <div class="services-style-two col-md-4 col-sm-6 col-xs-12">

                                                <div class="inner-box p-4">

                                                    <div class="block-number">02</div>

                                                    <h2><a href="catégories_de_causes.html">Partager <br> votre
                                                            campagne</a></h2>

                                                    <div class="text">
                                                        <ul>
                                                            <li>&#8226; Envoyer des e-mails.</li>
                                                            <li>&#8226; Envoyer des SMS.</li>
                                                            <li>&#8226; Partager-la sur les réseaux sociaux.</li>
                                                        </ul>
                                                    </div>

                                                </div>

                                            </div>
                                            <!--Services Style Two-->

                                            <div class="services-style-two col-md-4 col-sm-6 col-xs-12">

                                                <div class="inner-box p-4">

                                                    <div class="block-number">03</div>

                                                    <h2><a href="tableau de bord.html">Gérer <br>vos dons</a></h2>

                                                    <div class="text">
                                                        <ul>
                                                            <li>&#8226; Accepter des dons</li>
                                                            <li>&#8226; Remercier les donateurs</li>
                                                            <li>&#8226; Retirer les fonds.</li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                        </div>
                    </div>
                </div>
            </div>

            <!--End Services Section-->
            <!--News Block-->

    </div>

    <!--Sidebar Side-->

    <!--Subscribe Style One-->
    <section class="subscribe-style-one">
        <div class="auto-container">
            <div class="row clearfix">
                <div class="col-md-8 col-sm-12 col-xs-12">
                    <h2>Souscrire aux Newsletters</h2>
                    <div class="text">Entrer votre e-mail pour en savoir plus et rester en contact avec l'équipe
                        AidNov™</div>
                </div>
                <div class="col-md-4 col-sm-12 col-xs-12">
                    <form method="post" action="contact.html">
                        <div class="form-group">
                            <input type="email" name="email" value="" placeholder="Entrer votre e-mail" required>
                            <button type="submit" class="theme-btn"><span
                                    class="icon flaticon-send-message-button"></span></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <!--End Subscribe Style One-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/frontendother', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ProjectF\resources\views/frontend/mode_emploi.blade.php ENDPATH**/ ?>