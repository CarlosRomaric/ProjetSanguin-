<?php $__env->startSection('content'); ?>
     <!--Donate Section-->
        <section class="donate-section">
            <div class="auto-container">
                <!--Donate Block-->
                <div class="donate-block">
                    <div class="row clearfix">
                        <!--Image Column-->
                        <div class="image-column col-md-6 col-sm-12 col-xs-12">
                            <div class="image">
                                <img src="/photo/<?php echo e($campagne->photo); ?>" alt="" />
                            </div>
                        </div>
                        <!--Content Column-->
                        <div class="content-column col-md-6 col-sm-12 col-xs-12">
                            <h3><?php echo e($campagne->titre); ?></h3>
                            <!--<h4>Aidez moi à sauver mon fils</h4>-->
                            <div class="text">
                                <p><?php echo e($campagne->description); ?>.</p>
                                <p>Veuillez finaliser votre don en toute sécurité ci-dessous. En cas de questions ou
                                    d'aide ? Contactez <a href="tel:+22507088586"><span class="theme_color">(+225) 0708
                                            8586</span></a> ou envoyez un email <a href="mailto:aide@aidnov.com"><span
                                            class="theme_color">aide@aidnov.com</span></a></p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="donate-form-section">
                    <div class="donation-form-outer">
                        <form method="post" action="#" id="don">

                            <!--Form Portlet-->
                            <div class="form-portlet">
                                <h3>Combien aimeriez-vous donner ?</h3>
                                <div class="row clearfix" style="padding-bottom: 0; margin-bottom: 0;">
                                    <div class="form-group col-lg-8 col-md-8 col-xs-12 padd-top-20">
                                        <input id="prix" class="other-amount" required type="number" name="other-amount"
                                            placeholder="Montant en FCFA" min="1000">
                                    </div>
                                </div>
                                <p style="color: red;">Montant minimum accepté : 1000 FCFA</p>
                            </div>
                            <div class="form-portlet">
                            </div>
                            <div class="">
                                <h3 id="comment-pay">Comment aimeriez-vous donner ?</h3>
                                <div class="row clearfix">
                                    <div class="form-group col-lg-8 col-md-12 col-xs-12 clearfix">
                                        <div class="radio-select">
                                            <input type="radio" name="sel-moyen" id="amount-6">
                                            <label class="amount1" for="amount-6" id="money">Mobile Money</label>
                                        </div>
                                        <div class="radio-select">
                                            <input type="radio" name="sel-moyen" id="amount-7">
                                            <label class="amount2" for="amount-7" id="bancaire">Compte
                                                bancaire</label>
                                        </div>
                                    </div>
                                </div>
                            </div> 
                             <div class="payment-option-logo"><img class="img-responsive" id="logo-pay"
                                    src="/assets/images/resource/payment-logos.png" alt=""></div>
                             <br>
                            
                            <div class="form-portlet">
                            </div>
                            <div class="">
                                <h3 id="comment-pay">Profil donateur</h3>
                                <div class="row clearfix">
                             <div class="form-group col-lg-8 col-md-12 col-xs-12 clearfix">
                                 <div class="news-block">
                                                <div class="contact-form">
                                                    <div class="row
                                                                    clearfix">
                                                        <div class="form-group
                                                                        col-lg-6
                                                                        col-md-6
                                                                        col-xs-12">
                                                            <div class="field-label">Votre nom<span
                                                                    class="required">*</span>
                                                            </div>
                                                            <input id="nom" type="text" name="name" value=""
                                                                placeholder="Entrer votre nom" required>
                                                        </div>

                                                        <div class="form-group
                                                                        col-lg-6
                                                                        col-md-6
                                                                        col-xs-12">
                                                            <div class="field-label">Votre prénom(s)
                                                                <span class="required">*</span></div>
                                                            <input type="text" id="prenom" name="name" value=""
                                                                placeholder="Entrer votre prénom(s)" required>
                                                        </div>
                                                    </div>
                                                    <div class="row
                                                                    clearfix">
                                                        <div class="form-group
                                                                        col-lg-6
                                                                        col-md-6
                                                                        col-xs-12">
                                                            <div class="field-label">Votre
                                                                E-mail<span class="required">*</span></div>
                                                            <input id="email" type="email" name="name" value=""
                                                                placeholder="Entrer votre e-mal" required>
                                                        </div>
                                                        <div class="form-group
                                                                        col-lg-6
                                                                        col-md-6
                                                                        col-xs-12">
                                                            <div class="field-label">Numéro
                                                                de
                                                                téléphone<span class="required">*</span></div>
                                                            <input id="num" type="text" name="name" value=""
                                                                placeholder="Entrer votre numéro de téléphone" required>
                                                        </div>
                                                    </div>
                                                
                                                     <div class="row
                                                                    clearfix">
                                                        <div class="form-group
                                                                        col-lg-6
                                                                        col-md-6
                                                                        col-xs-12">
                                                            <div class="field-label">Comment Aimeriez-Vous Afficher Votre Don ?<span
                                                                    class="required">*</span></div>
                                                            <select name="country"
                                                                class="countries select-2 order-alpha presel-CI"
                                                                id="countryId">
                                                            <option>Publique</option>
                                                            <option>Anonyme</option>

                                                            </select>
                                                        </div>
                                                        <div class="form-group
                                                                        col-lg-6
                                                                        col-md-6
                                                                        col-xs-12">
                                                            <br>
                                                            <p class="medium">Vos données personnelles collectées seront affichées uniquement lorsque “Publique” est sélectionné pour l’affichage de votre don.<span
                                                                    class="required"></span></p>
                                                          
                                                        </div>
                                                    </div>
  
                                                </div>
                                            </div>
                                  <div class="form-portlet">
                                <div class="col-md-12 col-sm-12 col-xs-12">
                                    <ul class="footer-nav">
                                        <div>
                                            <p class="medium"><br> En cliquant sur <strong style="color:#bf4248 ;">"J'aide"</strong> vous acceptez
                                                les <a
                                                        href="https://drive.google.com/file/d/1ear0aODVdu8ew042SOXMM0MQ9ljYDrPn/view?usp=sharing"
                                                        target="_blank" style="color:#bf4248 ;">Conditions
                                                        générales d’utilisation</a> et accusez réception de la <a
                                                        href="https://drive.google.com/file/d/1EYm7Hg4i2_qOxnh0_kAnuLUiuA-zU5Kg/view?usp=sharing"
                                                        target="_blank" style="color:#bf4248 ;">Politique de
                                                        confidentialité</a> à <strong>AidNov™</strong> – A product of
                                                    LoHiDi<span id="®">®</span> Group. Vous serez redirigé sur une page de paiement sécurisé à l'étape suivante pour finaliser votre don.</p>
                                            </div>
                                        </ul>
                                    </div>
                                </div>


                                  <div class="form-group">
                                        <button type="submit" class="theme-btn btn-style-two">
                                            J'aide
                                        </button>
                                    </div>
                          
                                    </div>
                                </div>
                            </div>
                   
                           

        </section>
        <!--End Donate Section-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/frontendother', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ProjectF\resources\views/frontend/campagneDetail.blade.php ENDPATH**/ ?>