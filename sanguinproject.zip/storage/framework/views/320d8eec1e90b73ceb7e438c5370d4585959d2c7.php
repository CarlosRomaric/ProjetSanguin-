<!DOCTYPE html>
<!--[if IE 8 ]><html class="ie" xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!-->
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<!--<![endif]-->

<head>

	<!-- Basic Page Needs -->
	<meta charset="utf-8">

	<!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->

	<meta name="LoHiDi® Group" content="lohidi.com">
	<meta name="LoHiDi I IT®" content="it.lohidi.com">
	<meta name="LoHiDi I Creative®" content="creative.lohidi.com">
	<meta name="AidNov™">
	<meta name="#AIDONSNOUSVIVANT">

	<meta name="keywords"
		content="HTML, meta tag, tag reference, aide, donation, abidjan, aidons-nous, aidons, campagne, fonds, collecte de fonds, sante, famille, Commemoration, education, donate, famille, mariage, urgences, causes, crowdfunding, crowd, financement, financement participatif, collection, côte d'ivoire, aidons nous vivants, epidemie, lutter, pauvreté, religion, temoignages, financer, plateforme crowdfunding, project, afrique, africa, make a donation, realiser, entrepreneurs, crowdequity, crowdlending, prêt, investissement, ONG, ambassadeur, benevole, AidNov, LoHiDi® Group, LoHiDi I IT®, LoHiDi, facebook faire un don, aider une personne, #aidonsnousvivant, aidnov, démarrer un campagne, Faire un don, Devenir un Ambassadeur">

	<title>AidNov™ : Inscription</title>

	<!-- Stylesheets -->
	<link href="/assets/css/bootstrap.css" rel="stylesheet">
	<link href="/assets/css/style.css" rel="stylesheet">
	<link href="/assets/css/responsive.css" rel="stylesheet">

	<!--Color Switcher Mockup-->
	<link href="/assets/css/color-switcher-design.css" rel="stylesheet">

	<!--Color Themes-->
	<link id="theme-color-file" href="/assets/css/color-themes/default-theme.css" rel="stylesheet">

	<!--Favicon-->
	<link rel="shortcut icon" href="/assets/images/favicon.ico" type="image/x-icon">
	<link rel="icon" href="/assets/images/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">

	<!-- Responsive -->
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js">
	<!--[if lt IE 9]><script src="/https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
	<!--[if lt IE 9]><script src="/assets/js/respond.js"></script><![endif]-->

</head>

<body>
   <?php echo $__env->yieldContent('content'); ?>
<!--End Subscribe Style One-->

	<!--Scroll to top-->
	<div class="scroll-to-top scroll-to-target" data-target=".main-header"><span
			class="icon fa fa-long-arrow-up"></span></div>

	<script src="/assets/js/jquery.js"></script>
	<script src="/assets/js/bootstrap.min.js"></script>
	<script src="/assets/js/revolution.min.js"></script>
	<script src="/assets/js/jquery.fancybox.pack.js"></script>
	<script src="/assets/js/jquery.fancybox-media.js"></script>
	<script src="/assets/js/owl.js"></script>
	<script src="/assets/js/appear.js"></script>
	<script src="/assets/js/wow.js"></script>
	<script src="/assets/js/script.js"></script>
	<!-- <script src="/assets/js/main-2.js"></script> -->
	<script src="/assets/js/color-settings.js"></script>
	<!--<script src="/assets/js/validator.js"></script>-->
</body>

</html><?php /**PATH C:\wamp64\www\ProjectF\resources\views/layouts/auth.blade.php ENDPATH**/ ?>