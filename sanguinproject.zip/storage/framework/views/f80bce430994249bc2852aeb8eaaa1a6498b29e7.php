<?php $__env->startSection('content'); ?>
 <!--Page Title-->
        <section class="page-title" style="background-color: #376E50;">
            <div class="auto-container">
                <div class="inner-box">
                    <h3>Liste des Villes</h3>
                </div>
            </div>
        </section>
<!--End Page Title-->
     <!--Causes Section-->
        <section class="causes-section causes-grid-page">
            <div class="auto-container">
                <div class="row clearfix">
                    <?php if(Auth::user()->role==0): ?>
                        <?php echo $__env->make('inc/info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?>
                    <!--Causes Block-->
                    <form action="<?php echo e(route('ville.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                        <div class="form-group row">
                            <label for="pays" class="col-md-3">Pays</label>
                            <div class="col-md-6">
                               <select  name="pays_id" id="pays" class="form-control linked-select" data-target="#departement" data-dependent="pays">
                                    <option value="">Choississez votre pays</option>
                                    <?php $__currentLoopData = $pays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($p->id); ?>"><?php echo e($p->libelle); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="descriptioncause" class="col-md-3">Departement</label>
                            <div class="col-md-6">
                               <select  name="departement_id" id="departement" class="form-control">
                                    <option value="">Choississez votre departement</option>
                                   
                               </select>
                            </div>
                        </div>
                         <div class="form-group row">
                            <label for="libelle" class="col-md-3">Ville</label>
                            <div class="col-md-6">
                                <input type="text"  name="libelle" class="form-control" id="libelle" placeholder="Enter le libelle de la nom de la ville">   
                            </div>
                        </div>
                        <button type="submit" class="btn btn-success">Enregistrer</button>
                   </form>
                    <!--Causes Block-->
                    <!--<a href="<?php echo e(route('causeBack.create')); ?>" class="btn btn-primary">Enregistrer une cause</a>-->
                 
                    
                    <div class="table-responsive my-4">
                        <table class="table table-bordered text-center" id="example2">
                            <thead>
                            <tr>
                                    <th>Libellé</th> 
                                    <th>Departement</th> 
                                    <th>Action</tr>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $villes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ville): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="texte-center">
                                    <td><?php echo e($ville->libelle); ?></td>                                   
                                    <td><?php echo e($ville->departement->libelle); ?></td>                                   
                                    <td>
                                        <a href="#" class="btn btn-primary">Modifier</a>
                                        <button type="button" class="btn btn-danger">Supprimer </button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                   
                    
                    
                    
                    <!--Causes Block-->
                
                </div>
        </section>
        <!--End Causes Section-->



        <!--Subscribe Style One-->
        <section class="subscribe-style-one">
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="col-md-8 col-sm-12 col-xs-12">
                        <h2>Souscrire aux Newsletters</h2>
                        <div class="text">Entrer votre e-mail pour en savoir plus et rester en contact avec l'équipe
                            AidNov™</div>
                    </div>
                    <div class="col-md-4 col-sm-12 col-xs-12">
                        <form method="post" action="contact.html">
                            <div class="form-group">
                                <input type="email" name="email" value="" placeholder="Entrer votre e-mail" required>
                                <button type="submit" class="theme-btn"><span class="icon flaticon-send-message-button"></span></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
        <!--End Subscribe Style One-->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-js'); ?>
    <script>
            $(document).ready(function() {
              
                $("#example1").DataTable();
                $('#example2').DataTable({
                "paging": true,
                "lengthChange": true,
                "searching": true,
                "ordering": true,
                "info": true,
                "autoWidth": false,
                "language": {
                        processing:     "Traitement en cours...",
                        search:         "Rechercher&nbsp;:",
                        lengthMenu:     "Afficher _MENU_ &eacute;l&eacute;ments",
                        info:           "Affichage de l'&eacute;lement _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
                        infoEmpty:      "Affichage de l'&eacute;lement 0 &agrave; 0 sur 0 &eacute;l&eacute;ments",
                        infoFiltered:   "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
                        infoPostFix:    "",
                        loadingRecords: "Chargement en cours...",
                        zeroRecords:    "Aucun &eacute;l&eacute;ment &agrave; afficher",
                        emptyTable:     "Aucune donnée disponible dans le tableau",
                        paginate: {
                            first:      "Premier",
                            previous:   "Pr&eacute;c&eacute;dent",
                            next:       "Suivant",
                            last:       "Dernier"
                        },
                        aria: {
                            sortAscending:  ": activer pour trier la colonne par ordre croissant",
                            sortDescending: ": activer pour trier la colonne par ordre décroissant"
                        }
                    }
                });
            });

    </script>
    <script>
        $(document).ready(function(){
           $('#pays').on('change',function(e){
               console.log(e);             
               var pays_id = e.target.value;
               //ajax
               $.get('/ajax_departement?pays_id='+ pays_id, function(data){
                   //success data
                   console.log(data);
                   $('#departement').empty();
                   $.each(data, function(index, subcatObj){

                       $('#departement').append('<option value="'+subcatObj.id+'">'+subcatObj.libelle+'</option>');
                   });
               });
           });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ProjectF\resources\views/villes/index.blade.php ENDPATH**/ ?>