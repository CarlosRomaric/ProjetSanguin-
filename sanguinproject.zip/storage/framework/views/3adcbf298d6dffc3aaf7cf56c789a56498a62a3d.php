<ul class="navigation clearfix">
            <li class=""><a href="/">Accueil</a></li>
            <li class="dropdown">
                <a href="#">À propos</a>
                <ul>
                    <li><a href="<?php echo e(route('mode_emploi')); ?> ">Comment fonctionne AidNov™ ?</a></li>
                    <li><a href="<?php echo e(route('conseil_pour_collecter')); ?>">Conseils pour collecter des fonds</a></li>
                    <li><a href="<?php echo e(route('idees_pour_collecter')); ?>">Idées de collecte de fonds</a></li>
                    <li><a href="<?php echo e(route('a_propos')); ?>">Qui sommes-nous ?</a></li>
                </ul>
            </li>
            <li class="dropdown">
                <a href="/#">Découvrir</a>
                <ul>
                    <li><a href="<?php echo e(route('register')); ?>">Démarrer une campgane</a></li>
                    <li><a href="#">Faire un don</a></li>
                    <li><a href="<?php echo e(route('ambassadeur')); ?>">Devenir un Amabassadeur</a></li>
                    <li><a href="<?php echo e(route('temoignages')); ?>">Témoignages</a></li>
                </ul>
            </li>
                <li class="dropdown">
                    <a href="#">Causes</a>
                    <ul>
                        <li><a href="#">Santé</a></li>
                        <li><a href="#">Urgences</a></li>
                        <li><a href="#">Éducation</a></li>
                        <li><a href="#">Business</a></li>
                        <li><a href="#"><center>Voir tout</center></a></li>
                    </ul>
                </li>
            <li><a href="<?php echo e(route('contact')); ?>">Contact</a></li>
</ul><?php /**PATH C:\wamp64\www\ProjectF\resources\views/inc/ulnavigation.blade.php ENDPATH**/ ?>