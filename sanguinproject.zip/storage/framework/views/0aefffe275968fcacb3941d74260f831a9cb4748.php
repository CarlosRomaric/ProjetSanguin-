<?php $__env->startComponent('mail::message'); ?>
## Activation de compte
Merci pour votre inscription <?php echo e($user->name); ?> sur la plateforme Aidons nous
Clique sur le boutton ci dessous pour valider ton compte

<?php $__env->startComponent('mail::button', ['url' => '']); ?>
Valider mon Compte
<?php echo $__env->renderComponent(); ?>

Merci,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\wamp64\www\ProjectF\resources\views/emails/register.blade.php ENDPATH**/ ?>